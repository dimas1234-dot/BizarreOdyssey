package com.bizarreodyssey.stand;

import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class TimeStopManager {
    private static final Map<String, TimeStopState> ACTIVE_TIME_STOPS = new ConcurrentHashMap<>();

    public record TimeStopState(UUID casterUuid, int remainingTicks, double centerX, double centerY, double centerZ) {}

    public static void triggerTimeStop(ServerPlayerEntity caster, int durationTicks) {
        String dimKey = caster.getWorld().getRegistryKey().getValue().toString();
        ACTIVE_TIME_STOPS.put(dimKey, new TimeStopState(
                caster.getUuid(), durationTicks, caster.getX(), caster.getY(), caster.getZ()
        ));

        ServerWorld world = caster.getServerWorld();
        world.playSound(null, caster.getBlockPos(), SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.PLAYERS, 2.0f, 0.5f);
        world.spawnParticles(ParticleTypes.SONIC_BOOM, caster.getX(), caster.getY() + 1.0, caster.getZ(), 4, 0.5, 0.5, 0.5, 0.0);

        for (ServerPlayerEntity player : world.getPlayers()) {
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.timestop_start", caster.getName()).formatted(Formatting.GOLD, Formatting.BOLD), true);
        }
    }

    public static void tickServerWorld(ServerWorld world) {
        String dimKey = world.getRegistryKey().getValue().toString();
        TimeStopState state = ACTIVE_TIME_STOPS.get(dimKey);
        if (state == null) return;

        if (state.remainingTicks() <= 1) {
            ACTIVE_TIME_STOPS.remove(dimKey);
            world.playSound(null, state.centerX(), state.centerY(), state.centerZ(),
                    SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 1.5f, 1.4f);
            for (ServerPlayerEntity player : world.getPlayers()) {
                player.sendMessage(Text.translatable("msg.bizarre_odyssey.timestop_resume").formatted(Formatting.AQUA, Formatting.ITALIC), true);
            }
        } else {
            ACTIVE_TIME_STOPS.put(dimKey, new TimeStopState(
                    state.casterUuid(), state.remainingTicks() - 1, state.centerX(), state.centerY(), state.centerZ()
            ));
        }
    }

    public static boolean isEntityFrozen(Entity entity) {
        if (entity == null || entity.getWorld() == null) return false;
        String dimKey = entity.getWorld().getRegistryKey().getValue().toString();
        TimeStopState state = ACTIVE_TIME_STOPS.get(dimKey);
        if (state == null) return false;

        if (entity.getUuid().equals(state.casterUuid())) {
            return false;
        }
        if (entity instanceof PlayerEntity player && player instanceof IJoJoPlayerData data) {
            if (data.bizarre$getStand().canMoveInTimeStop()) {
                return false;
            }
        }
        return entity.squaredDistanceTo(state.centerX(), state.centerY(), state.centerZ()) <= 64.0 * 64.0;
    }
}
