package com.bizarreodyssey.stand;

import net.minecraft.util.Formatting;

public enum StandType {
    NONE("none", "No Stand", "Без Стенда", 0, 0x888888, Formatting.GRAY,
            "Empty Soul", "Barren Resolve", "Plain Instinct", "Last Breath", false, "none", 0.0f, 0),

    // PART 3: Stardust Crusaders
    STAR_PLATINUM("star_platinum", "Star Platinum", "Стар Платинум", 3, 0x9B59B6, Formatting.LIGHT_PURPLE,
            "ORA Barrage (50 hits)", "Star Finger (Pierce)", "Inhale & Crusher", "The World (Time Stop 5s)", true, "star_platinum_tw", 10.5f, 100),
    STAR_PLATINUM_THE_WORLD("star_platinum_tw", "Star Platinum: The World", "Стар Платинум: Зе Ворлд", 4, 0x6C3483, Formatting.DARK_PURPLE,
            "Relentless ORA Barrage", "Bearing Shot (Precision)", "Time Skip Dash", "Prime Time Stop (9s)", true, "star_platinum_oh", 13.0f, 180),
    STAR_PLATINUM_OVER_HEAVEN("star_platinum_oh", "Star Platinum: Over Heaven", "Стар Платинум: Овер Хевен", 3, 0xF1C40F, Formatting.GOLD,
            "Reality Overwrite Barrage", "Heavenly Lightning Strike", "Ascended Soul Heal", "Universe Time Stop (15s)", true, "none", 18.5f, 300),

    THE_WORLD("the_world", "The World", "Зе Ворлд", 3, 0xF4D03F, Formatting.YELLOW,
            "MUDA Barrage (50 hits)", "Checkmate Knives Volley", "Time Skip Behind Target", "Toki Wo Tomare (Time Stop 9s)", true, "the_world_oh", 11.0f, 180),
    THE_WORLD_OVER_HEAVEN("the_world_oh", "The World: Over Heaven", "Зе Ворлд: Овер Хевен", 3, 0xFFF9C4, Formatting.GOLD,
            "True MUDA Overwrite", "Reality Delete Punch", "Divine Smite", "ROAD ROLLER DA + Overwrite (15s)", true, "none", 19.0f, 300),

    MAGICIANS_RED("magicians_red", "Magician's Red", "Маджиシャンз Ред", 3, 0xE74C3C, Formatting.RED,
            "Flame Wing Barrage", "Red Bind (Fire Lasso)", "Crossfire Hurricane", "Crossfire Hurricane: Special", false, "none", 9.0f, 0),
    HIEROPHANT_GREEN("hierophant_green", "Hierophant Green", "Иерофант Грин", 3, 0x2ECC71, Formatting.GREEN,
            "Tentacle Whip Barrage", "Emerald Splash", "Hierophant Barrier Trap", "20-Meter Radius Emerald Splash", false, "none", 8.5f, 0),
    SILVER_CHARIOT("silver_chariot", "Silver Chariot", "Сильвер Чариот", 3, 0xBDC3C7, Formatting.AQUA,
            "HORA Rapier Barrage", "Million Pricks", "Armor Off (Speed x2.5)", "Shooting Sword Pierce", false, "chariot_requiem", 9.0f, 0),
    CHARIOT_REQUIEM("chariot_requiem", "Chariot Requiem", "Чариот Реквием", 5, 0x2C3E50, Formatting.DARK_GRAY,
            "Shadow Domination", "Soul Swap Aura", "Stand Reflection", "Conqueror's Slumber (Mass Sleep)", false, "none", 14.0f, 0),
    CREAM("cream", "Cream", "Крим", 3, 0x8E44AD, Formatting.DARK_PURPLE,
            "Dark Space Claw", "Void Ball Charge", "Dimension Hop", "Spiral Void Erasure", false, "none", 11.5f, 0),

    // PART 4: Diamond is Unbreakable
    CRAZY_DIAMOND("crazy_diamond", "Crazy Diamond", "Крейзи Даймонд", 4, 0xFF85A2, Formatting.LIGHT_PURPLE,
            "DORA Barrage", "Restoration Touch (Heal Ally)", "Rock Trap Wall", "DORARARA Rage Mode (Unstoppable)", false, "none", 10.0f, 0),
    THE_HAND("the_hand", "The Hand", "Зе Хэнд", 4, 0x2980B9, Formatting.BLUE,
            "Heavy Swipe Barrage", "Erasure (Brrrzt!)", "Space Pull Teleport", "Double Erasure Cleave", false, "none", 12.5f, 0),
    KILLER_QUEEN("killer_queen", "Killer Queen", "Киллер Квин", 4, 0xF5B7B1, Formatting.LIGHT_PURPLE,
            "SHIBABA Barrage", "Primary Bomb Plant & Detonate", "Sheer Heart Attack (Kocchi wo Miro)", "Coin Toss Air Bomb", false, "killer_queen_btd", 9.5f, 0),
    KILLER_QUEEN_BTD("killer_queen_btd", "Killer Queen: Bites the Dust", "Киллер Квин: Байтс зе Даст", 4, 0xD98880, Formatting.DARK_RED,
            "Explosive SHIBABA Barrage", "Stray Cat Bubble Bomb", "Sheer Heart Attack Unleashed", "Bites the Dust (Rewind Time & Heal)", false, "none", 13.5f, 0),

    // PART 5: Golden Wind
    GOLD_EXPERIENCE("gold_experience", "Gold Experience", "Голд Экспериенс", 5, 0xF39C12, Formatting.GOLD,
            "7-Page MUDA Barrage", "Life Giver (Self/Ally Heal)", "Frog Damage Reflection", "Sensory Overload Berserk", false, "gold_experience_requiem", 9.0f, 0),
    GOLD_EXPERIENCE_REQUIEM("gold_experience_requiem", "Gold Experience Requiem", "Голд Экспериенс Реквием", 5, 0xFFD700, Formatting.YELLOW,
            "Infinite MUDA Barrage", "Scorpion Laser Beam", "Life Restoration Pulse", "Return to Zero (RTZ Counter & Death Loop)", true, "none", 17.5f, 0),
    STICKY_FINGERS("sticky_fingers", "Sticky Fingers", "Стики Фингерс", 5, 0x3498DB, Formatting.BLUE,
            "ARI-ARI-ARI Barrage", "Extend Arm Hook", "Zipper Glide", "Arrivederci! (Dismember Strike)", false, "none", 9.0f, 0),
    KING_CRIMSON("king_crimson", "King Crimson", "Кинг Кримзон", 5, 0xC0392B, Formatting.DARK_RED,
            "Crimson Chop Barrage", "Epitaph (Future Sight Dodge)", "Impale Donut Strike", "Time Erase (10s Invulnerable Phase)", false, "king_crimson_requiem", 12.0f, 0),
    KING_CRIMSON_REQUIEM("king_crimson_requiem", "King Crimson Requiem", "Кинг Кримзон Реквием", 5, 0x7B241C, Formatting.DARK_RED,
            "Destiny Sever Barrage", "Absolute Epitaph Counter", "Dimension Scythe", "Eternal Court of the Crimson King", false, "none", 16.5f, 0),

    // PART 6: Stone Ocean
    STONE_FREE("stone_free", "Stone Free", "Стоун Фри", 6, 0x1ABC9C, Formatting.DARK_AQUA,
            "ORA String Barrage", "String Tether Grapple", "String Barrier Net", "Mobius Strip Defense + Home Run", false, "none", 9.5f, 0),
    WHITESNAKE("whitesnake", "Whitesnake", "Уайтснейк", 6, 0xEAECEE, Formatting.WHITE,
            "USHYA Acid Barrage", "Spirit DISC Steal (Silence)", "Melt Your Heart Acid Pool", "Beretta Burst + Stand Steal", false, "c_moon", 9.5f, 0),
    C_MOON("c_moon", "C-Moon", "Си-Мун", 6, 0x27AE60, Formatting.GREEN,
            "Gravity Inversion Barrage", "Surface Inversion Punch (Inside-Out)", "Gravitational Shift Repulse", "Center of Gravity Launch", false, "made_in_heaven", 13.0f, 0),
    MADE_IN_HEAVEN("made_in_heaven", "Made in Heaven", "Мейд ин Хевен", 6, 0xF7DC6F, Formatting.GOLD,
            "Lightspeed Knife Slash", "Heaven's Judgment Dash", "Time Acceleration (Speed x5)", "Universe Reset (Singularity Point)", false, "none", 17.0f, 0),
    WEATHER_REPORT("weather_report", "Weather Report", "Уэзер Репорт", 6, 0x5DADE2, Formatting.AQUA,
            "Gale Force Barrage", "Lightning Bolt Call", "Oxygen 100% Poison Cloud", "Heavy Weather (Snail Subliminal)", false, "none", 11.5f, 0),

    // PART 7: Steel Ball Run & Beyond
    TUSK_ACT_1("tusk_act_1", "Tusk ACT 1", "Таск АКТ 1", 7, 0xF1948A, Formatting.LIGHT_PURPLE,
            "Nail Spin Slash", "Nail Bullets (5 shots)", "Herb Tea Regeneration", "Focused Nail Volley", false, "tusk_act_2", 7.0f, 0),
    TUSK_ACT_2("tusk_act_2", "Tusk ACT 2", "Таск АКТ 2", 7, 0xE74C3C, Formatting.RED,
            "Golden Rectangle Nails", "Tracking Spatial Hole", "Tea & Spin Focus", "Golden Ratio Piercing Shot", false, "tusk_act_3", 9.0f, 0),
    TUSK_ACT_3("tusk_act_3", "Tusk ACT 3", "Таск АКТ 3", 7, 0x8E44AD, Formatting.DARK_PURPLE,
            "Spatial Wormhole Nails", "Wormhole Uppercut", "Dark Determination Teleport", "Infinite Spatial Ambush", false, "tusk_act_4", 11.5f, 0),
    TUSK_ACT_4("tusk_act_4", "Tusk ACT 4", "Таск АКТ 4", 7, 0xFF69B4, Formatting.LIGHT_PURPLE,
            "CHUMIMIN~!! ORA Barrage", "Barrier Rip (Ignores Love Train)", "Golden Rotation Ride", "Infinite Rotation Shot (Bypass Time Stop)", true, "none", 18.0f, 0),
    DIRTY_DEEDS_DONE_DIRT_CHEAP("d4c", "Dirty Deeds Done Dirt Cheap (D4C)", "D4C", 7, 0x5499C7, Formatting.AQUA,
            "CHibababa Chop Barrage", "Dimension Clones (3 Valentines)", "Flag Dimension Hop", "Paradox Obliteration (Menger Sponge)", false, "d4c_love_train", 12.0f, 0),
    D4C_LOVE_TRAIN("d4c_love_train", "D4C: Love Train", "D4C: Лав Трейн", 7, 0xF9E79F, Formatting.GOLD,
            "Presidential Barrage", "Revolver + Clone Ambush", "Dimension Hop", "Love Train Wall of Light (Redirect Misfortune)", false, "none", 17.5f, 0),
    SCARY_MONSTERS("scary_monsters", "Scary Monsters", "Скери Монстерс", 7, 0x16A085, Formatting.DARK_GREEN,
            "USHAAA Raptor Claw Barrage", "Fossilize Minion Summon", "Utahraptor Pounce", "Full Dinosaur Transformation", false, "none", 11.0f, 0),
    SOFT_AND_WET_GO_BEYOND("soft_and_wet_gb", "Soft & Wet: Go Beyond", "Софт энд Вет: Гоу Бийонд", 7, 0x85C1E9, Formatting.AQUA,
            "ORA Kick & Shovel Barrage", "Friction & Sight Plunder Bubble", "Explosive Spin Bubble", "Go Beyond! (Invisible Non-Existent Bubble)", true, "none", 17.0f, 0);

    private final String id;
    private final String displayNameEn;
    private final String displayNameRu;
    private final int part;
    private final int auraColor;
    private final Formatting formatting;
    private final String skill1Name;
    private final String skill2Name;
    private final String skill3Name;
    private final String ultimateName;
    private final boolean canMoveInTimeStop;
    private final String nextEvolutionId;
    private final float basePower;
    private final int timeStopTicks;

    StandType(String id, String displayNameEn, String displayNameRu, int part, int auraColor, Formatting formatting,
              String skill1Name, String skill2Name, String skill3Name, String ultimateName,
              boolean canMoveInTimeStop, String nextEvolutionId, float basePower, int timeStopTicks) {
        this.id = id;
        this.displayNameEn = displayNameEn;
        this.displayNameRu = displayNameRu;
        this.part = part;
        this.auraColor = auraColor;
        this.formatting = formatting;
        this.skill1Name = skill1Name;
        this.skill2Name = skill2Name;
        this.skill3Name = skill3Name;
        this.ultimateName = ultimateName;
        this.canMoveInTimeStop = canMoveInTimeStop;
        this.nextEvolutionId = nextEvolutionId;
        this.basePower = basePower;
        this.timeStopTicks = timeStopTicks;
    }

    public String getId() { return id; }
    public String getDisplayNameEn() { return displayNameEn; }
    public String getDisplayNameRu() { return displayNameRu; }
    public int getPart() { return part; }
    public int getAuraColor() { return auraColor; }
    public Formatting getFormatting() { return formatting; }
    public String getSkill1Name() { return skill1Name; }
    public String getSkill2Name() { return skill2Name; }
    public String getSkill3Name() { return skill3Name; }
    public String getUltimateName() { return ultimateName; }
    public boolean canMoveInTimeStop() { return canMoveInTimeStop; }
    public String getNextEvolutionId() { return nextEvolutionId; }
    public float getBasePower() { return basePower; }
    public int getTimeStopTicks() { return timeStopTicks; }

    public static StandType byId(String id) {
        for (StandType type : values()) {
            if (type.id.equalsIgnoreCase(id)) {
                return type;
            }
        }
        return NONE;
    }

    public static StandType[] getArrowPool() {
        return new StandType[]{
                STAR_PLATINUM, THE_WORLD, MAGICIANS_RED, HIEROPHANT_GREEN, SILVER_CHARIOT, CREAM,
                CRAZY_DIAMOND, THE_HAND, KILLER_QUEEN,
                GOLD_EXPERIENCE, STICKY_FINGERS, KING_CRIMSON,
                STONE_FREE, WHITESNAKE, WEATHER_REPORT
        };
    }

    public static StandType[] getRibCagePool() {
        return new StandType[]{
                TUSK_ACT_1, DIRTY_DEEDS_DONE_DIRT_CHEAP, SCARY_MONSTERS, SOFT_AND_WORTH_CHECK()
        };
    }

    private static StandType SOFT_AND_WORTH_CHECK() {
        return SOFT_AND_WET_GO_BEYOND;
    }
}
