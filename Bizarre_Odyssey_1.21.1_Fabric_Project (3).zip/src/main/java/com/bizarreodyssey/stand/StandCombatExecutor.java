package com.bizarreodyssey.stand;

import com.bizarreodyssey.entity.ModEntities;
import com.bizarreodyssey.entity.StandEntity;
import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.registry.ModSounds;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class StandCombatExecutor {

    public static void toggleStandSummon(ServerPlayerEntity player) {
        if (!(player instanceof IJoJoPlayerData data)) return;
        StandType stand = data.bizarre$getStand();
        if (stand == StandType.NONE) {
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.no_stand").formatted(Formatting.RED), true);
            return;
        }

        boolean newState = !data.bizarre$isStandSummoned();
        data.bizarre$setStandSummoned(newState);
        ServerWorld world = player.getServerWorld();

        if (newState) {
            StandEntity standEntity = new StandEntity(ModEntities.STAND_ENTITY, world);
            standEntity.refreshPositionAndAngles(player.getX(), player.getY() + 0.5, player.getZ(), player.getYaw(), player.getPitch());
            standEntity.setOwner(player);
            world.spawnEntity(standEntity);

            world.playSound(null, player.getBlockPos(), ModSounds.STAND_SUMMON, SoundCategory.PLAYERS, 1.2f, 1.0f);
            world.spawnParticles(ParticleTypes.ENCHANTED_HIT, player.getX(), player.getY() + 1.0, player.getZ(), 35, 0.5, 0.9, 0.5, 0.15);
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_summoned", stand.getDisplayNameRu()).formatted(stand.getFormatting(), Formatting.BOLD), true);
        } else {
            world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.7f, 0.6f);
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_recalled").formatted(Formatting.GRAY), true);
        }
        ModNetworking.syncToClient(player);
    }

    public static void executeStandSkill(ServerPlayerEntity player, int skillSlot) {
        if (!(player instanceof IJoJoPlayerData data)) return;
        StandType stand = data.bizarre$getStand();
        if (stand == StandType.NONE) return;

        if (!data.bizarre$isStandSummoned()) {
            toggleStandSummon(player);
        }

        int cdIndex = skillSlot - 1;
        if (data.bizarre$getCooldown(cdIndex) > 0) {
            int sec = (data.bizarre$getCooldown(cdIndex) + 19) / 20;
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.cooldown_wait", sec).formatted(Formatting.RED), true);
            return;
        }

        ServerWorld world = player.getServerWorld();
        float power = stand.getBasePower();

        // Trigger barrage animation on nearby StandEntity owned by player
        List<StandEntity> stands = world.getEntitiesByClass(StandEntity.class, player.getBoundingBox().expand(8.0), e -> true);
        for (StandEntity se : stands) {
            se.triggerBarrageAnim(25);
        }

        switch (skillSlot) {
            case 1 -> {
                // SKILL 1: Signature Stand Barrage (ORA / MUDA / DORA / ARI / USHYA / CHUMIMIN)
                data.bizarre$setCooldown(0, 80); // 4s cooldown
                Vec3d look = player.getRotationVec(1.0f);
                Box hitBox = player.getBoundingBox().stretch(look.multiply(4.5)).expand(1.75);
                List<LivingEntity> targets = world.getEntitiesByClass(LivingEntity.class, hitBox,
                        e -> e != player && !(e instanceof StandEntity) && e.isAlive());

                for (LivingEntity target : targets) {
                    target.damage(world.getDamageSources().playerAttack(player), power * 1.45f);
                    target.setVelocity(look.x * 0.45, 0.22, look.z * 0.45);
                    target.velocityModified = true;
                    world.spawnParticles(ParticleTypes.CRIT, target.getX(), target.getY() + 1.0, target.getZ(), 25, 0.4, 0.6, 0.4, 0.2);
                }

                world.spawnParticles(ParticleTypes.SWEEP_ATTACK,
                        player.getX() + look.x * 2.0, player.getY() + 1.2, player.getZ() + look.z * 2.0,
                        12, 0.6, 0.5, 0.6, 0.0);
                world.playSound(null, player.getBlockPos(), ModSounds.ORA_BARRAGE, SoundCategory.PLAYERS, 1.3f, 1.0f);
                player.sendMessage(Text.literal("[" + stand.getDisplayNameRu() + "] " + stand.getSkill1Name() + "!").formatted(stand.getFormatting(), Formatting.BOLD), true);
            }
            case 2 -> {
                // SKILL 2: Ranged / Tactical Strike (Star Finger, Knives, Emerald Splash, Bomb Plant, Nail Shots, Spirit DISC)
                data.bizarre$setCooldown(1, 140); // 7s cooldown
                Vec3d look = player.getRotationVec(1.0f);

                for (int step = 1; step <= 12; step++) {
                    Vec3d pos = player.getEyePos().add(look.multiply(step * 1.2));
                    world.spawnParticles(ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 4, 0.15, 0.15, 0.15, 0.02);
                    Box rayBox = new Box(pos.x - 1.2, pos.y - 1.2, pos.z - 1.2, pos.x + 1.2, pos.y + 1.2, pos.z + 1.2);
                    List<LivingEntity> hit = world.getEntitiesByClass(LivingEntity.class, rayBox,
                            e -> e != player && !(e instanceof StandEntity) && e.isAlive());

                    for (LivingEntity target : hit) {
                        target.damage(world.getDamageSources().playerAttack(player), power * 1.65f);
                        if (stand == StandType.MAGICIANS_RED) {
                            target.setOnFireFor(6);
                        } else if (stand == StandType.KILLER_QUEEN || stand == StandType.KILLER_QUEEN_BTD) {
                            world.createExplosion(player, target.getX(), target.getY(), target.getZ(), 2.2f, World.ExplosionSourceType.NONE);
                        } else if (stand == StandType.WHITESNAKE) {
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 160, 2));
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 160, 2));
                        } else if (stand == StandType.CRAZY_DIAMOND || stand == StandType.GOLD_EXPERIENCE || stand == StandType.GOLD_EXPERIENCE_REQUIEM) {
                            player.heal(6.0f);
                        }
                    }
                }
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, SoundCategory.PLAYERS, 1.2f, 1.2f);
                player.sendMessage(Text.literal("[" + stand.getDisplayNameRu() + "] " + stand.getSkill2Name() + "!").formatted(stand.getFormatting(), Formatting.BOLD), true);
            }
            case 3 -> {
                // SKILL 3: Mobility / Space / Counter Utility (Time Skip, Space Pull, Zipper Glide, Epitaph, Gravity Shift, Clones)
                data.bizarre$setCooldown(2, 180); // 9s cooldown
                Vec3d look = player.getRotationVec(1.0f);

                if (stand == StandType.THE_HAND || stand == StandType.CREAM) {
                    // Erasure Dash + Space Pull
                    Box pullBox = player.getBoundingBox().stretch(look.multiply(8.0)).expand(2.5);
                    for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, pullBox, e -> e != player && !(e instanceof StandEntity))) {
                        target.refreshPositionAndAngles(player.getX() + look.x * 1.5, player.getY(), player.getZ() + look.z * 1.5, target.getYaw(), target.getPitch());
                        target.damage(world.getDamageSources().magic(), power * 1.8f);
                    }
                    world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.4f, 0.5f);
                } else {
                    // Time Skip / Zipper Glide / Wormhole / Speed Step
                    Vec3d dest = player.getPos().add(look.multiply(7.5));
                    player.requestTeleport(dest.x, dest.y + 0.2, dest.z);
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 120, 2));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 80, 1));
                    world.spawnParticles(ParticleTypes.PORTAL, dest.x, dest.y + 1.0, dest.z, 40, 0.5, 0.8, 0.5, 0.1);
                    world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.2f, 1.1f);
                }
                player.sendMessage(Text.literal("[" + stand.getDisplayNameRu() + "] " + stand.getSkill3Name() + "!").formatted(stand.getFormatting(), Formatting.BOLD), true);
            }
            case 4 -> {
                // SKILL 4: ULTIMATE ABILITY (Time Stop, Return to Zero, Time Erase, Bites the Dust, Love Train, Infinite Rotation, Universe Reset, Go Beyond)
                data.bizarre$setCooldown(3, 400); // 20s cooldown

                if (stand.getTimeStopTicks() > 0) {
                    TimeStopManager.triggerTimeStop(player, stand.getTimeStopTicks());
                    ModAdvancementTracker.grantAdvancement(player, "stands/time_stop_master");
                } else if (stand == StandType.GOLD_EXPERIENCE_REQUIEM) {
                    // Return to Zero (RTZ): Full heal, cleanse, invulnerability + AoE Death Loop
                    player.setHealth(player.getMaxHealth());
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 4));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 3));
                    for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, player.getBoundingBox().expand(10.0), e -> e != player && !(e instanceof StandEntity))) {
                        e.damage(world.getDamageSources().magic(), power * 2.4f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 4));
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 60, 1));
                    }
                    world.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.2, player.getZ(), 100, 1.5, 1.5, 1.5, 0.3);
                    ModAdvancementTracker.grantAdvancement(player, "stands/return_to_zero");
                } else if (stand == StandType.KING_CRIMSON || stand == StandType.KING_CRIMSON_REQUIEM) {
                    // Time Erase (Diavolo): Invisible + Invulnerable phase + Ambush Chop
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 180, 0));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 180, 4));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 180, 3));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200, 2));
                    world.playSound(null, player.getBlockPos(), ModSounds.TIME_ERASE, SoundCategory.PLAYERS, 1.5f, 0.7f);
                    ModAdvancementTracker.grantAdvancement(player, "stands/king_crimson_erase");
                } else if (stand == StandType.KILLER_QUEEN_BTD) {
                    // Bites the Dust: Rewind Health to Full + Huge Shockwave Detonation
                    player.setHealth(player.getMaxHealth());
                    for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, player.getBoundingBox().expand(9.0), e -> e != player && !(e instanceof StandEntity))) {
                        e.damage(world.getDamageSources().explosion(player, player), power * 2.5f);
                        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, e.getX(), e.getY() + 1.0, e.getZ(), 2, 0.2, 0.2, 0.2, 0.0);
                    }
                    world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 1.5f, 0.8f);
                } else if (stand == StandType.MADE_IN_HEAVEN) {
                    // Universe Reset / Time Acceleration
                    world.setTimeOfDay(world.getTimeOfDay() + 12000L);
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 4));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 300, 2));
                    for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, player.getBoundingBox().expand(12.0), e -> e != player && !(e instanceof StandEntity))) {
                        e.damage(world.getDamageSources().playerAttack(player), power * 2.2f);
                    }
                    ModAdvancementTracker.grantAdvancement(player, "stands/made_in_heaven_reset");
                } else if (stand == StandType.D4C_LOVE_TRAIN) {
                    // Love Train Wall of Light: Redirects all misfortune around the player
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 300, 4));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 240, 3));
                    for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, player.getBoundingBox().expand(8.0), e -> e != player && !(e instanceof StandEntity))) {
                        e.damage(world.getDamageSources().magic(), power * 2.0f);
                    }
                    world.spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(), 90, 1.5, 2.0, 1.5, 0.05);
                } else {
                    // Tusk ACT 4 Infinite Rotation / Soft & Wet Go Beyond / High Impact Ultimate
                    Vec3d look = player.getRotationVec(1.0f);
                    Box ultBox = player.getBoundingBox().stretch(look.multiply(10.0)).expand(3.0);
                    for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, ultBox, e -> e != player && !(e instanceof StandEntity))) {
                        e.damage(world.getDamageSources().magic(), power * 2.6f);
                        e.setVelocity(0, 0.8, 0);
                        e.velocityModified = true;
                    }
                    world.spawnParticles(ParticleTypes.SONIC_BOOM, player.getX() + look.x * 3.0, player.getY() + 1.2, player.getZ() + look.z * 3.0, 5, 0.5, 0.5, 0.5, 0.0);
                    world.playSound(null, player.getBlockPos(), ModSounds.CHUMIMIN, SoundCategory.PLAYERS, 1.5f, 1.0f);
                }
                player.sendMessage(Text.literal("[" + stand.getDisplayNameRu() + "] ULTIMATE: " + stand.getUltimateName() + "!").formatted(Formatting.GOLD, Formatting.BOLD), false);
            }
        }
        ModNetworking.syncToClient(player);
    }
}
