package com.bizarreodyssey.world;

import com.bizarreodyssey.BizarreOdysseyMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

public class ModWorldGen {
    public static final RegistryKey<PlacedFeature> METEORITE_ORE_PLACED_KEY = RegistryKey.of(
            RegistryKeys.PLACED_FEATURE, BizarreOdysseyMod.id("meteorite_ore_placed"));

    public static final RegistryKey<PlacedFeature> MORIOH_SHRINE_PLACED_KEY = RegistryKey.of(
            RegistryKeys.PLACED_FEATURE, BizarreOdysseyMod.id("morioh_angelo_patch_placed"));

    public static final RegistryKey<PlacedFeature> DEVILS_PALM_PLACED_KEY = RegistryKey.of(
            RegistryKeys.PLACED_FEATURE, BizarreOdysseyMod.id("devils_palm_patch_placed"));

    public static void registerWorldGen() {
        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.UNDERGROUND_ORES,
                METEORITE_ORE_PLACED_KEY
        );
        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.LOCAL_MODIFICATIONS,
                MORIOH_SHRINE_PLACED_KEY
        );
        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.LOCAL_MODIFICATIONS,
                DEVILS_PALM_PLACED_KEY
        );
        BizarreOdysseyMod.LOGGER.info("Registered Bizarre Odyssey World Generation Features.");
    }
}
