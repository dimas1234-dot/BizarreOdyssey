package com.bizarreodyssey.world;

import com.bizarreodyssey.registry.ModBlocks;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

public class JoJoStructureBuilder {

    public static void buildStructureAt(ServerWorld world, BlockPos origin, String type) {
        switch (type.toLowerCase()) {
            case "meteorite_crater" -> buildMeteoriteCrater(world, origin);
            case "cairo_shrine" -> buildCairoShrine(world, origin);
            case "morioh_landmark" -> buildMoriohLandmark(world, origin);
            case "devils_palm" -> buildDevilsPalm(world, origin);
            default -> buildMeteoriteCrater(world, origin);
        }
    }

    public static void buildMeteoriteCrater(ServerWorld world, BlockPos center) {
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (dx * dx + dz * dz <= 16) {
                    world.setBlockState(center.add(dx, -1, dz), Blocks.BLACKSTONE.getDefaultState());
                    world.setBlockState(center.add(dx, 0, dz), Blocks.MAGMA_BLOCK.getDefaultState());
                }
            }
        }
        world.setBlockState(center, ModBlocks.METEORITE_IRON_BLOCK.getDefaultState());
        world.setBlockState(center.add(1, 0, 0), ModBlocks.METEORITE_ORE.getDefaultState());
        world.setBlockState(center.add(-1, 0, 0), ModBlocks.METEORITE_ORE.getDefaultState());
        world.setBlockState(center.add(0, 0, 1), ModBlocks.METEORITE_ORE.getDefaultState());
        world.setBlockState(center.add(0, 1, 0), ModBlocks.METEORITE_ORE.getDefaultState());
    }

    public static void buildCairoShrine(ServerWorld world, BlockPos center) {
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                world.setBlockState(center.add(dx, -1, dz), Blocks.SMOOTH_SANDSTONE.getDefaultState());
            }
        }
        for (int y = 0; y <= 4; y++) {
            world.setBlockState(center.add(-4, y, -4), ModBlocks.CAIRO_SANDSTONE_PILLAR.getDefaultState());
            world.setBlockState(center.add(4, y, -4), ModBlocks.CAIRO_SANDSTONE_PILLAR.getDefaultState());
            world.setBlockState(center.add(-4, y, 4), ModBlocks.CAIRO_SANDSTONE_PILLAR.getDefaultState());
            world.setBlockState(center.add(4, y, 4), ModBlocks.CAIRO_SANDSTONE_PILLAR.getDefaultState());
        }
        world.setBlockState(center, ModBlocks.HEAVEN_ALTAR.getDefaultState());
    }

    public static void buildMoriohLandmark(ServerWorld world, BlockPos center) {
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                world.setBlockState(center.add(dx, -1, dz), ModBlocks.MORIOH_PAVEMENT.getDefaultState());
            }
        }
        world.setBlockState(center, ModBlocks.ANGELO_ROCK.getDefaultState());
        world.setBlockState(center.up(), ModBlocks.ANGELO_ROCK.getDefaultState());
        world.setBlockState(center.add(2, 0, 0), ModBlocks.WALL_EYES_STONE.getDefaultState());
        world.setBlockState(center.add(-2, 0, 0), ModBlocks.WALL_EYES_STONE.getDefaultState());
    }

    public static void buildDevilsPalm(ServerWorld world, BlockPos center) {
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (dx * dx + dz * dz <= 18) {
                    world.setBlockState(center.add(dx, -1, dz), ModBlocks.DEVILS_PALM_SAND.getDefaultState());
                }
            }
        }
        world.setBlockState(center, ModBlocks.HEAVEN_ALTAR.getDefaultState());
    }
}
