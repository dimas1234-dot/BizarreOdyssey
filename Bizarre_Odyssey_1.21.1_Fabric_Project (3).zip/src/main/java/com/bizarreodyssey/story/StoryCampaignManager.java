package com.bizarreodyssey.story;

import com.bizarreodyssey.entity.ModEntities;
import com.bizarreodyssey.entity.StoryBossEntity;
import com.bizarreodyssey.entity.StoryMentorNpcEntity;
import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.registry.ModItems;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

public class StoryCampaignManager {

    public static String getShortHudObjective(int stage, int kills) {
        return switch (stage) {
            case 0 -> "Гл. 1 (Ч.3): Пробуди Стенд Стрелой или поговори с Джотаро";
            case 1 -> "Гл. 2 (Ч.3): Победи 3 культистов ДИО (" + kills + "/3)";
            case 2 -> "Гл. 3 (Ч.3): Поговори с Джозефом Джостаром (Shift+ПКМ Компасом)";
            case 3 -> "Гл. 4 (Ч.3): Одолей ДИО БРАНДО в Каире!";
            case 4 -> "Гл. 5 (Ч.4): Встреться с Роханом Кишибе в Морио";
            case 5 -> "Гл. 6 (Ч.4): Очисти Морио от 3 владельцев Стендов (" + kills + "/3)";
            case 6 -> "Гл. 7 (Ч.4): Одолей Йошикаге Киру (Killer Queen)!";
            case 7 -> "Гл. 8 (Ч.5): Поговори с Джорно Джованной в Неаполе";
            case 8 -> "Гл. 9 (Ч.5): Разгроми 3 киллеров La Squadra (" + kills + "/3)";
            case 9 -> "Гл. 10 (Ч.5): Одолей Босса Дьяволо в Колизее!";
            case 10 -> "Гл. 11 (Ч.6): Поговори с Джолин Куджо во Флориде";
            case 11 -> "Гл. 12 (Ч.6): Останови 3 последователей Пуччи (" + kills + "/3)";
            case 12 -> "Гл. 13 (Ч.6): Одолей Энрико Пуччи на мысе Канаверал!";
            case 13 -> "Гл. 14 (Ч.7): Встреться с Джайро Цеппели на старте Steel Ball Run";
            case 14 -> "Гл. 15 (Ч.7): Одолей 3 наемников Валентайна в Ладони Дьявола (" + kills + "/3)";
            case 15 -> "Гл. 16 (Ч.7): Финал! Победи Президента Фанни Валентайна (D4C)!";
            default -> "Сюжет Частей 3–7 пройден! Достигни Небес (Over Heaven / Requiem)!";
        };
    }

    public static void printCurrentObjective(ServerPlayerEntity player) {
        if (!(player instanceof IJoJoPlayerData data)) return;
        int stage = data.bizarre$getStoryStage();
        int kills = data.bizarre$getStoryKillProgress();
        player.sendMessage(Text.literal("========================================").formatted(Formatting.GOLD), false);
        player.sendMessage(Text.translatable("msg.bizarre_odyssey.story_header").formatted(Formatting.GOLD, Formatting.BOLD), false);
        player.sendMessage(Text.literal(getShortHudObjective(stage, kills)).formatted(Formatting.YELLOW), false);
        player.sendMessage(Text.translatable("msg.bizarre_odyssey.story_compass_hint").formatted(Formatting.AQUA), false);
        player.sendMessage(Text.literal("========================================").formatted(Formatting.GOLD), false);
    }

    public static void spawnCurrentChapterActor(ServerPlayerEntity player) {
        if (!(player instanceof IJoJoPlayerData data)) return;
        int stage = data.bizarre$getStoryStage();
        ServerWorld world = player.getServerWorld();
        Vec3d look = player.getRotationVec(1.0f);
        double sx = player.getX() + look.x * 4.0;
        double sy = player.getY() + 0.5;
        double sz = player.getZ() + look.z * 4.0;

        switch (stage) {
            case 0 -> spawnMentor(world, sx, sy, sz, "jotaro_kujo", player);
            case 1, 5, 8, 11, 14 -> spawnBoss(world, sx, sy, sz, "cultist_minion", player);
            case 2 -> spawnMentor(world, sx, sy, sz, "joseph_joestar", player);
            case 3 -> spawnBoss(world, sx, sy, sz, "dio_brando", player);
            case 4 -> spawnMentor(world, sx, sy, sz, "rohan_kishibe", player);
            case 6 -> spawnBoss(world, sx, sy, sz, "yoshikage_kira", player);
            case 7 -> spawnMentor(world, sx, sy, sz, "giorno_giovanna", player);
            case 9 -> spawnBoss(world, sx, sy, sz, "diavolo", player);
            case 10 -> spawnMentor(world, sx, sy, sz, "jolyne_cujoh", player);
            case 12 -> spawnBoss(world, sx, sy, sz, "enrico_pucci", player);
            case 13 -> spawnMentor(world, sx, sy, sz, "gyro_zeppeli", player);
            case 15 -> spawnBoss(world, sx, sy, sz, "funny_valentine", player);
            default -> {
                spawnBoss(world, sx, sy, sz, "dio_brando", player);
                player.sendMessage(Text.translatable("msg.bizarre_odyssey.story_replay_boss").formatted(Formatting.GOLD), true);
            }
        }
    }

    private static void spawnMentor(ServerWorld world, double x, double y, double z, String mentorId, ServerPlayerEntity player) {
        StoryMentorNpcEntity npc = new StoryMentorNpcEntity(ModEntities.STORY_MENTOR, world);
        npc.refreshPositionAndAngles(x, y, z, player.getYaw() + 180.0f, 0.0f);
        npc.configureMentor(mentorId);
        world.spawnEntity(npc);
        world.spawnParticles(ParticleTypes.END_ROD, x, y + 1.0, z, 25, 0.4, 0.8, 0.4, 0.05);
        world.playSound(null, npc.getBlockPos(), SoundEvents.ENTITY_ILLUSIONER_MIRROR_MOVE, SoundCategory.NEUTRAL, 1.0f, 1.2f);
    }

    private static void spawnBoss(ServerWorld world, double x, double y, double z, String bossId, ServerPlayerEntity player) {
        StoryBossEntity boss = new StoryBossEntity(ModEntities.STORY_BOSS, world);
        boss.refreshPositionAndAngles(x, y, z, player.getYaw() + 180.0f, 0.0f);
        boss.configureBossType(bossId);
        world.spawnEntity(boss);
        world.spawnParticles(ParticleTypes.FLAME, x, y + 1.0, z, 40, 0.5, 1.0, 0.5, 0.08);
        world.playSound(null, boss.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 1.2f, 1.1f);
    }

    public static void onInteractWithMentor(ServerPlayerEntity player, String mentorId) {
        if (!(player instanceof IJoJoPlayerData data)) return;
        int stage = data.bizarre$getStoryStage();

        if (stage == 0 && "jotaro_kujo".equals(mentorId)) {
            if (data.bizarre$getStand() == StandType.NONE) {
                player.giveItemStack(new ItemStack(ModItems.STAND_ARROW, 2));
                player.giveItemStack(new ItemStack(ModItems.JOTARO_CAP, 1));
                player.sendMessage(Text.translatable("dialogue.bizarre_odyssey.jotaro_give_arrow").formatted(Formatting.AQUA), false);
            } else {
                data.bizarre$setStoryStage(1);
                data.bizarre$setStoryKillProgress(0);
                player.sendMessage(Text.translatable("dialogue.bizarre_odyssey.jotaro_start_part3").formatted(Formatting.GOLD, Formatting.BOLD), false);
                ModNetworking.syncToClient(player);
            }
        } else if (stage == 2 && "joseph_joestar".equals(mentorId)) {
            data.bizarre$setStoryStage(3);
            player.giveItemStack(new ItemStack(ModItems.ZEPPELIS_HAMON_WINE, 1));
            player.sendMessage(Text.translatable("dialogue.bizarre_odyssey.joseph_cairo_ready").formatted(Formatting.GOLD, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if (stage == 4 && "rohan_kishibe".equals(mentorId)) {
            data.bizarre$setStoryStage(5);
            data.bizarre$setStoryKillProgress(0);
            player.giveItemStack(new ItemStack(ModItems.TONIOS_CAPRESE_SALAD, 2));
            player.sendMessage(Text.translatable("dialogue.bizarre_odyssey.rohan_morioh_quest").formatted(Formatting.GREEN, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if (stage == 7 && "giorno_giovanna".equals(mentorId)) {
            data.bizarre$setStoryStage(8);
            data.bizarre$setStoryKillProgress(0);
            player.giveItemStack(new ItemStack(ModItems.TORTURE_DANCE_BOOMBOX, 1));
            player.sendMessage(Text.translatable("dialogue.bizarre_odyssey.giorno_passione_quest").formatted(Formatting.GOLD, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if (stage == 10 && "jolyne_cujoh".equals(mentorId)) {
            data.bizarre$setStoryStage(11);
            data.bizarre$setStoryKillProgress(0);
            player.giveItemStack(new ItemStack(ModItems.STAND_ARROW, 2));
            player.sendMessage(Text.translatable("dialogue.bizarre_odyssey.jolyne_prison_quest").formatted(Formatting.AQUA, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if (stage == 13 && "gyro_zeppeli".equals(mentorId)) {
            data.bizarre$setStoryStage(14);
            data.bizarre$setStoryKillProgress(0);
            player.giveItemStack(new ItemStack(ModItems.GYROS_STEEL_BALL, 1));
            player.giveItemStack(new ItemStack(ModItems.SAINTS_RIB_CAGE, 1));
            player.sendMessage(Text.translatable("dialogue.bizarre_odyssey.gyro_sbr_quest").formatted(Formatting.GREEN, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else {
            printCurrentObjective(player);
        }
    }

    public static void onBossOrMinionDefeated(ServerPlayerEntity player, String bossType) {
        if (!(player instanceof IJoJoPlayerData data)) return;
        int stage = data.bizarre$getStoryStage();

        if ("cultist_minion".equals(bossType) && (stage == 1 || stage == 5 || stage == 8 || stage == 11 || stage == 14)) {
            int kills = data.bizarre$getStoryKillProgress() + 1;
            data.bizarre$setStoryKillProgress(kills);
            if (kills >= 3) {
                data.bizarre$setStoryStage(stage + 1);
                data.bizarre$setStoryKillProgress(0);
                data.bizarre$setWorthiness(Math.min(5, data.bizarre$getWorthiness() + 1));
                player.sendMessage(Text.translatable("msg.bizarre_odyssey.story_stage_advanced").formatted(Formatting.GREEN, Formatting.BOLD), false);
            } else {
                player.sendMessage(Text.literal("Сюжетный прогресс зачистки: " + kills + "/3").formatted(Formatting.YELLOW), true);
            }
            ModNetworking.syncToClient(player);
        } else if ("dio_brando".equals(bossType) && stage == 3) {
            data.bizarre$setStoryStage(4);
            data.bizarre$setWorthiness(5);
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.part3_complete").formatted(Formatting.GOLD, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if ("yoshikage_kira".equals(bossType) && stage == 6) {
            data.bizarre$setStoryStage(7);
            data.bizarre$setWorthiness(5);
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.part4_complete").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if ("diavolo".equals(bossType) && stage == 9) {
            data.bizarre$setStoryStage(10);
            data.bizarre$setWorthiness(5);
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.part5_complete").formatted(Formatting.RED, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if ("enrico_pucci".equals(bossType) && stage == 12) {
            data.bizarre$setStoryStage(13);
            data.bizarre$setWorthiness(5);
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.part6_complete").formatted(Formatting.AQUA, Formatting.BOLD), false);
            ModNetworking.syncToClient(player);
        } else if ("funny_valentine".equals(bossType) && stage == 15) {
            data.bizarre$setStoryStage(16);
            data.bizarre$setWorthiness(5);
            player.giveItemStack(new ItemStack(ModItems.LUCKY_ARROW, 1));
            player.giveItemStack(new ItemStack(ModItems.LOCACACA_6251, 1));
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.part7_complete").formatted(Formatting.GOLD, Formatting.BOLD), false);
            ModAdvancementTracker.grantAdvancement(player, "story/true_bizarre_odyssey_complete");
            ModNetworking.syncToClient(player);
        }
    }
}
