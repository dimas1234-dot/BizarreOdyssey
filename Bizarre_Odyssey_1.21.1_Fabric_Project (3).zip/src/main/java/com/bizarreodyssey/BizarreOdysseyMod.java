package com.bizarreodyssey;

import com.bizarreodyssey.command.JoJoCommands;
import com.bizarreodyssey.entity.ModEntities;
import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModBlocks;
import com.bizarreodyssey.registry.ModItems;
import com.bizarreodyssey.registry.ModSounds;
import com.bizarreodyssey.stand.TimeStopManager;
import com.bizarreodyssey.util.IJoJoPlayerData;
import com.bizarreodyssey.world.ModWorldGen;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BizarreOdysseyMod implements ModInitializer {
    public static final String MOD_ID = "bizarre_odyssey";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModSounds.registerAll();
        ModBlocks.registerAll();
        ModItems.registerAll();
        ModEntities.registerAll();
        ModNetworking.registerCommon();
        ModWorldGen.registerWorldGen();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> JoJoCommands.register(dispatcher));

        // Keep Stand, Spec, Worthiness, and Story progress across deaths!
        ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
            if (oldPlayer instanceof IJoJoPlayerData oldData && newPlayer instanceof IJoJoPlayerData newData) {
                newData.bizarre$readData(oldData.bizarre$writeData());
            }
        });

        // Give Story Journal Compass & Stand Arrow on first join & sync data
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            if (player instanceof IJoJoPlayerData data) {
                if (!player.getCommandTags().contains("bizarre_odyssey_welcomed")) {
                    player.addCommandTag("bizarre_odyssey_welcomed");
                    player.giveItemStack(new ItemStack(ModItems.STORY_JOURNAL_COMPASS, 1));
                    player.giveItemStack(new ItemStack(ModItems.STAND_ARROW, 1));
                    player.sendMessage(Text.translatable("msg.bizarre_odyssey.welcome_gift").formatted(Formatting.GOLD, Formatting.BOLD), false);
                }
                ModNetworking.syncToClient(player);
            }
        });

        // Tick player cooldowns and Time Stop state
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            TimeStopManager.tickServerWorld(world);
            for (ServerPlayerEntity player : world.getPlayers()) {
                if (player instanceof IJoJoPlayerData data) {
                    data.bizarre$tickCooldowns();
                    if (world.getTime() % 10 == 0) {
                        ModNetworking.syncToClient(player);
                    }
                }
            }
        });

        LOGGER.info("Bizarre Odyssey (Parts 3-7 Story & Stands) initialized for Minecraft 1.21.1 Fabric!");
    }
}
