package com.bizarreodyssey;

import com.bizarreodyssey.client.hud.JoJoHudOverlay;
import com.bizarreodyssey.client.render.StandEntityModel;
import com.bizarreodyssey.client.render.StandEntityRenderer;
import com.bizarreodyssey.client.render.StoryActorRenderer;
import com.bizarreodyssey.entity.ModEntities;
import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class BizarreOdysseyClient implements ClientModInitializer {
    private static KeyBinding summonKey;
    private static KeyBinding skill1Key;
    private static KeyBinding skill2Key;
    private static KeyBinding skill3Key;
    private static KeyBinding ultimateKey;
    private static KeyBinding spec1Key;
    private static KeyBinding spec2Key;
    private static KeyBinding spec3Key;

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(StandEntityModel.LAYER_LOCATION, StandEntityModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.STAND_ENTITY, StandEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.STORY_BOSS, ctx -> new StoryActorRenderer<>(ctx, "story_boss"));
        EntityRendererRegistry.register(ModEntities.STORY_MENTOR, ctx -> new StoryActorRenderer<>(ctx, "story_mentor"));

        HudRenderCallback.EVENT.register(new JoJoHudOverlay());

        summonKey = registerKey("key.bizarre_odyssey.summon_stand", GLFW.GLFW_KEY_V);
        skill1Key = registerKey("key.bizarre_odyssey.stand_skill_1", GLFW.GLFW_KEY_Z);
        skill2Key = registerKey("key.bizarre_odyssey.stand_skill_2", GLFW.GLFW_KEY_X);
        skill3Key = registerKey("key.bizarre_odyssey.stand_skill_3", GLFW.GLFW_KEY_C);
        ultimateKey = registerKey("key.bizarre_odyssey.stand_ultimate", GLFW.GLFW_KEY_R);
        spec1Key = registerKey("key.bizarre_odyssey.spec_skill_1", GLFW.GLFW_KEY_G);
        spec2Key = registerKey("key.bizarre_odyssey.spec_skill_2", GLFW.GLFW_KEY_H);
        spec3Key = registerKey("key.bizarre_odyssey.spec_skill_3", GLFW.GLFW_KEY_J);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (summonKey.wasPressed()) sendAction(0);
            while (skill1Key.wasPressed()) sendAction(1);
            while (skill2Key.wasPressed()) sendAction(2);
            while (skill3Key.wasPressed()) sendAction(3);
            while (ultimateKey.wasPressed()) sendAction(4);
            while (spec1Key.wasPressed()) sendAction(5);
            while (spec2Key.wasPressed()) sendAction(6);
            while (spec3Key.wasPressed()) sendAction(7);
        });

        ClientPlayNetworking.registerGlobalReceiver(ModNetworking.SyncPlayerDataS2CPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                if (context.client().player instanceof IJoJoPlayerData data) {
                    data.bizarre$setStand(StandType.byId(payload.standId()));
                    data.bizarre$setSpec(SpecType.byId(payload.specId()));
                    data.bizarre$setStandSummoned(payload.summoned());
                    data.bizarre$setWorthiness(payload.worthiness());
                    data.bizarre$setStandEnergy(payload.energy());
                    data.bizarre$setStoryStage(payload.storyStage());
                    data.bizarre$setStoryKillProgress(payload.storyKills());
                    data.bizarre$setCooldown(0, payload.cd0());
                    data.bizarre$setCooldown(1, payload.cd1());
                    data.bizarre$setCooldown(2, payload.cd2());
                    data.bizarre$setCooldown(3, payload.cd3());
                    data.bizarre$setCooldown(4, payload.cd4());
                }
            });
        });
    }

    private static KeyBinding registerKey(String translationKey, int keyCode) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                translationKey,
                InputUtil.Type.KEYSYM,
                keyCode,
                "category.bizarre_odyssey.controls"
        ));
    }

    private static void sendAction(int actionId) {
        ClientPlayNetworking.send(new ModNetworking.StandActionC2SPayload(actionId));
    }
}
