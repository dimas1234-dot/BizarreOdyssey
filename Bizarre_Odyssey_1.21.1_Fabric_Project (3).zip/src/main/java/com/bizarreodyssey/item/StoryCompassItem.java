package com.bizarreodyssey.item;

import com.bizarreodyssey.story.StoryCampaignManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class StoryCompassItem extends Item {
    public StoryCompassItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer) {
            if (user.isSneaking()) {
                StoryCampaignManager.spawnCurrentChapterActor(serverPlayer);
            } else {
                StoryCampaignManager.printCurrentObjective(serverPlayer);
            }
            return TypedActionResult.success(stack);
        }
        return TypedActionResult.pass(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.bizarre_odyssey.story_compass_1").formatted(Formatting.GOLD));
        tooltip.add(Text.translatable("tooltip.bizarre_odyssey.story_compass_2").formatted(Formatting.AQUA));
    }
}
