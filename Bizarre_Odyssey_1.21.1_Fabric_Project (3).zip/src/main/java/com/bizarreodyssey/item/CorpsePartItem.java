package com.bizarreodyssey.item;

import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class CorpsePartItem extends Item {
    public enum PartKind { RIB_CAGE, LEFT_ARM, PELVIS, HEART }

    private final PartKind kind;

    public CorpsePartItem(Settings settings, PartKind kind) {
        super(settings);
        this.kind = kind;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer && user instanceof IJoJoPlayerData data) {
            StandType current = data.bizarre$getStand();

            switch (kind) {
                case RIB_CAGE -> {
                    if (current != StandType.NONE) {
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.already_has_stand").formatted(Formatting.YELLOW), true);
                        return TypedActionResult.fail(stack);
                    }
                    StandType[] pool = StandType.getRibCagePool();
                    StandType rolled = pool[world.random.nextInt(pool.length)];
                    data.bizarre$setStand(rolled);
                    data.bizarre$setStandSummoned(true);
                    stack.decrement(1);
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.corpse_stand_awakened", rolled.getDisplayNameRu()).formatted(Formatting.GOLD, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/first_stand");
                }
                case LEFT_ARM -> {
                    if (current == StandType.TUSK_ACT_1) {
                        data.bizarre$setStand(StandType.TUSK_ACT_2);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", StandType.TUSK_ACT_2.getDisplayNameRu()).formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), false);
                    } else if (current == StandType.TUSK_ACT_2) {
                        data.bizarre$setStand(StandType.TUSK_ACT_3);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", StandType.TUSK_ACT_3.getDisplayNameRu()).formatted(Formatting.DARK_PURPLE, Formatting.BOLD), false);
                    } else {
                        data.bizarre$setWorthiness(5);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.worthiness_max").formatted(Formatting.GOLD), true);
                    }
                }
                case PELVIS -> {
                    if (current == StandType.TUSK_ACT_3) {
                        data.bizarre$setStand(StandType.TUSK_ACT_4);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", StandType.TUSK_ACT_4.getDisplayNameRu()).formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), false);
                        ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/lesson_five_tusk4");
                    } else {
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.pelvis_need_tusk3").formatted(Formatting.RED), true);
                        return TypedActionResult.fail(stack);
                    }
                }
                case HEART -> {
                    if (current == StandType.DIRTY_DEEDS_DONE_DIRT_CHEAP) {
                        data.bizarre$setStand(StandType.D4C_LOVE_TRAIN);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", StandType.D4C_LOVE_TRAIN.getDisplayNameRu()).formatted(Formatting.GOLD, Formatting.BOLD), false);
                        ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/love_train_barrier");
                    } else {
                        data.bizarre$setWorthiness(5);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.worthiness_max").formatted(Formatting.GOLD), true);
                    }
                }
            }

            serverPlayer.getServerWorld().spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 1.1, user.getZ(), 50, 0.6, 1.0, 0.6, 0.15);
            world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.2f, 1.2f);
            ModNetworking.syncToClient(serverPlayer);
            return TypedActionResult.success(stack);
        }
        return TypedActionResult.pass(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.bizarre_odyssey.corpse_" + kind.name().toLowerCase()).formatted(Formatting.GOLD));
    }
}
