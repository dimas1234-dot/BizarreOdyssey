package com.bizarreodyssey.item;

import com.bizarreodyssey.registry.ModAdvancementTracker;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class AnimeEasterEggItem extends Item {
    private final String eggId;

    public AnimeEasterEggItem(Settings settings, String eggId) {
        super(settings);
        this.eggId = eggId;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer) {
            switch (eggId) {
                case "oolong_tea" -> {
                    // Grand Blue Reference: Combustible 96% Spirit "Oolong Tea"
                    serverPlayer.setOnFireFor(3);
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 400, 2));
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 400, 1));
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0));
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.oolong_tea_burn").formatted(Formatting.GOLD, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "easter_eggs/combustible_oolong_tea");
                    stack.decrement(1);
                }
                case "torture_boombox" -> {
                    // Part 5 Vocal Percussion on a whole 'notha level
                    serverPlayer.getServerWorld().spawnParticles(ParticleTypes.NOTE, user.getX(), user.getY() + 1.8, user.getZ(), 45, 1.2, 0.8, 1.2, 1.0);
                    world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_NOTE_BLOCK_GUITAR.value(), SoundCategory.RECORDS, 2.0f, 1.2f);
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 600, 1));
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.torture_dance").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "easter_eggs/vocal_percussion");
                }
                case "tonio_caprese" -> {
                    // Part 4 Tonio Trussardi's Pearl Jam Caprese Salad
                    serverPlayer.setHealth(serverPlayer.getMaxHealth());
                    serverPlayer.getHungerManager().add(20, 20.0f);
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 600, 2));
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 1200, 2));
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.tonio_healed").formatted(Formatting.GREEN, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "easter_eggs/pearl_jam_gourmet");
                    stack.decrement(1);
                }
                case "panzer_track_talisman" -> {
                    // Girls und Panzer Reference: Nishizumi Style Drift!
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 2));
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 600, 1));
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.panzer_vor").formatted(Formatting.AQUA, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "easter_eggs/panzer_vor_drift");
                }
                case "delusion_emblem" -> {
                    // Genshin Impact Snezhnaya Fatui / Mondstadt Crossover Reference
                    serverPlayer.getServerWorld().spawnParticles(ParticleTypes.SNOWFLAKE, user.getX(), user.getY() + 1.0, user.getZ(), 50, 0.8, 0.8, 0.8, 0.1);
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 500, 1));
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.snezhnaya_delusion").formatted(Formatting.AQUA, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "easter_eggs/tsaritsa_blessing");
                }
                case "cursed_finger_relic" -> {
                    // Jujutsu Kaisen Reference
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 2));
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 200, 0));
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.domain_expansion").formatted(Formatting.DARK_RED, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "easter_eggs/malevolent_stand");
                    stack.decrement(1);
                }
                case "Pluck_Sword" -> {
                    // Part 1 Luck & Pluck Sword
                    serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200, 1));
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.luck_and_pluck").formatted(Formatting.GOLD), true);
                }
            }
            return TypedActionResult.success(stack);
        }
        return TypedActionResult.pass(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.bizarre_odyssey.egg_" + eggId).formatted(Formatting.ITALIC, Formatting.GRAY));
    }
}
