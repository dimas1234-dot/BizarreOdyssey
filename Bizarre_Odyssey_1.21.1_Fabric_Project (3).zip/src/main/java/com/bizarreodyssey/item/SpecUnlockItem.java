package com.bizarreodyssey.item;

import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class SpecUnlockItem extends Item {
    private final SpecType targetSpec;

    public SpecUnlockItem(Settings settings, SpecType targetSpec) {
        super(settings);
        this.targetSpec = targetSpec;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer && user instanceof IJoJoPlayerData data) {
            data.bizarre$setSpec(targetSpec);
            serverPlayer.getServerWorld().spawnParticles(ParticleTypes.FLAME, user.getX(), user.getY() + 1.0, user.getZ(), 35, 0.5, 0.8, 0.5, 0.08);
            world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_TOTEM_USE, SoundCategory.PLAYERS, 1.0f, 1.2f);
            serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.spec_unlocked", targetSpec.getNameRu()).formatted(targetSpec.getColor()), false);

            switch (targetSpec) {
                case HAMON -> ModAdvancementTracker.grantAdvancement(serverPlayer, "specs/hamon_warrior");
                case VAMPIRISM -> ModAdvancementTracker.grantAdvancement(serverPlayer, "specs/reject_humanity");
                case BOXING -> ModAdvancementTracker.grantAdvancement(serverPlayer, "specs/boxing_champion");
                case SPIN -> ModAdvancementTracker.grantAdvancement(serverPlayer, "specs/golden_spin_master");
                case CYBORG -> ModAdvancementTracker.grantAdvancement(serverPlayer, "specs/german_science_sekai_ichi");
                default -> {}
            }

            ModNetworking.syncToClient(serverPlayer);
            return TypedActionResult.success(stack);
        }
        return TypedActionResult.pass(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.bizarre_odyssey.spec_" + targetSpec.getId()).formatted(targetSpec.getColor()));
    }
}
