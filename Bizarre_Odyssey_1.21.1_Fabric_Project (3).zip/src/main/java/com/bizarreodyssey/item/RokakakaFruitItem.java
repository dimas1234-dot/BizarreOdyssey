package com.bizarreodyssey.item;

import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

public class RokakakaFruitItem extends Item {
    private final boolean isPureRokakaka;

    public RokakakaFruitItem(Settings settings, boolean isPureRokakaka) {
        super(settings);
        this.isPureRokakaka = isPureRokakaka;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer && user instanceof IJoJoPlayerData data) {
            if (isPureRokakaka) {
                data.bizarre$setSpec(SpecType.NONE);
                data.bizarre$setWorthiness(5);
                serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.pure_roka_used").formatted(Formatting.AQUA, Formatting.BOLD), false);
            } else {
                data.bizarre$setStand(StandType.NONE);
                data.bizarre$setSpec(SpecType.NONE);
                data.bizarre$setStandSummoned(false);
                data.bizarre$setWorthiness(2);
                serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
                serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.roka_used").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), false);
                ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/equivalent_exchange");
            }
            serverPlayer.getServerWorld().spawnParticles(ParticleTypes.SMOKE, user.getX(), user.getY() + 1.0, user.getZ(), 40, 0.5, 0.8, 0.5, 0.05);
            world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_STONE_BREAK, SoundCategory.PLAYERS, 1.0f, 0.8f);
            ModNetworking.syncToClient(serverPlayer);
        }
        return super.finishUsing(stack, world, user);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable(isPureRokakaka ? "tooltip.bizarre_odyssey.pure_rokakaka" : "tooltip.bizarre_odyssey.rokakaka").formatted(Formatting.LIGHT_PURPLE));
    }
}
