package com.bizarreodyssey.item;

import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class StandArrowItem extends Item {
    private final boolean isRequiemArrow;
    private final boolean isLuckyArrow;

    public StandArrowItem(Settings settings, boolean isRequiemArrow, boolean isLuckyArrow) {
        super(settings);
        this.isRequiemArrow = isRequiemArrow;
        this.isLuckyArrow = isLuckyArrow;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer && user instanceof IJoJoPlayerData data) {
            StandType current = data.bizarre$getStand();

            if (isRequiemArrow) {
                if (current == StandType.NONE) {
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.requiem_need_stand").formatted(Formatting.RED), true);
                    return TypedActionResult.fail(stack);
                }
                if (data.bizarre$getWorthiness() < 5) {
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.worthiness_low").formatted(Formatting.RED), true);
                    user.damage(world.getDamageSources().magic(), 8.0f);
                    return TypedActionResult.fail(stack);
                }

                StandType evolved = switch (current) {
                    case GOLD_EXPERIENCE -> StandType.GOLD_EXPERIENCE_REQUIEM;
                    case SILVER_CHARIOT -> StandType.CHARIOT_REQUIEM;
                    case KING_CRIMSON -> StandType.KING_CRIMSON_REQUIEM;
                    case KILLER_QUEEN -> StandType.KILLER_QUEEN_BTD;
                    case STAR_PLATINUM -> StandType.STAR_PLATINUM_THE_WORLD;
                    default -> StandType.NONE;
                };

                if (evolved == StandType.NONE) {
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.requiem_reject").formatted(Formatting.YELLOW), true);
                    return TypedActionResult.fail(stack);
                }

                data.bizarre$setStand(evolved);
                data.bizarre$setStandSummoned(true);
                stack.decrement(1);
                serverPlayer.getServerWorld().spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, user.getX(), user.getY() + 1.2, user.getZ(), 90, 0.8, 1.2, 0.8, 0.25);
                world.playSound(null, user.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1.5f, 1.0f);
                serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", evolved.getDisplayNameRu()).formatted(Formatting.GOLD, Formatting.BOLD), false);

                ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/requiem_awakening");
                if (evolved == StandType.KILLER_QUEEN_BTD) {
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/bites_the_dust");
                }
                ModNetworking.syncToClient(serverPlayer);
                return TypedActionResult.success(stack);
            }

            if (current != StandType.NONE) {
                serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.already_has_stand").formatted(Formatting.YELLOW), true);
                return TypedActionResult.fail(stack);
            }

            if (data.bizarre$getWorthiness() < 1 && !isLuckyArrow) {
                user.damage(world.getDamageSources().magic(), 14.0f);
                serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.arrow_rejected").formatted(Formatting.DARK_RED), false);
                return TypedActionResult.fail(stack);
            }

            StandType[] pool = StandType.getArrowPool();
            StandType rolled = pool[world.random.nextInt(pool.length)];
            data.bizarre$setStand(rolled);
            data.bizarre$setStandSummoned(true);
            stack.decrement(1);

            serverPlayer.getServerWorld().spawnParticles(ParticleTypes.ENCHANT, user.getX(), user.getY() + 1.0, user.getZ(), 60, 0.6, 1.0, 0.6, 0.2);
            world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.2f, 0.8f);
            serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_awakened", rolled.getDisplayNameRu()).formatted(rolled.getFormatting(), Formatting.BOLD), false);

            ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/first_stand");
            if (isLuckyArrow) {
                ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/lucky_arrow_shine");
            }
            ModNetworking.syncToClient(serverPlayer);
            return TypedActionResult.success(stack);
        }
        return TypedActionResult.pass(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        if (isRequiemArrow) {
            tooltip.add(Text.translatable("tooltip.bizarre_odyssey.requiem_arrow").formatted(Formatting.GOLD));
        } else if (isLuckyArrow) {
            tooltip.add(Text.translatable("tooltip.bizarre_odyssey.lucky_arrow").formatted(Formatting.AQUA));
        } else {
            tooltip.add(Text.translatable("tooltip.bizarre_odyssey.stand_arrow").formatted(Formatting.YELLOW));
        }
    }
}
