package com.bizarreodyssey.item;

import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class EvolutionCatalystItem extends Item {
    public enum CatalystKind { DIOS_DIARY, DIOS_BONE, GREEN_BABY, LOCACACA_6251 }

    private final CatalystKind kind;

    public EvolutionCatalystItem(Settings settings, CatalystKind kind) {
        super(settings);
        this.kind = kind;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity serverPlayer && user instanceof IJoJoPlayerData data) {
            StandType current = data.bizarre$getStand();

            switch (kind) {
                case DIOS_DIARY -> {
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.diary_phrases").formatted(Formatting.GOLD, Formatting.ITALIC), false);
                    if ((current == StandType.THE_WORLD || current == StandType.STAR_PLATINUM || current == StandType.STAR_PLATINUM_THE_WORLD)
                            && user.getY() >= 180.0 && data.bizarre$getDioBoneSteps() >= 2) {
                        StandType heaven = (current == StandType.THE_WORLD) ? StandType.THE_WORLD_OVER_HEAVEN : StandType.STAR_PLATINUM_OVER_HEAVEN;
                        data.bizarre$setStand(heaven);
                        stack.decrement(1);
                        serverPlayer.getServerWorld().spawnParticles(ParticleTypes.FLASH, user.getX(), user.getY() + 1.0, user.getZ(), 5, 0.2, 0.2, 0.2, 0.0);
                        world.playSound(null, user.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 2.0f, 0.9f);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", heaven.getDisplayNameRu()).formatted(Formatting.GOLD, Formatting.BOLD), false);
                        ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/over_heaven_ascension");
                        ModNetworking.syncToClient(serverPlayer);
                        return TypedActionResult.success(stack);
                    } else if (current == StandType.C_MOON && user.getY() >= 150.0) {
                        data.bizarre$setStand(StandType.MADE_IN_HEAVEN);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", StandType.MADE_IN_HEAVEN.getDisplayNameRu()).formatted(Formatting.GOLD, Formatting.BOLD), false);
                        ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/made_in_heaven_reset");
                        ModNetworking.syncToClient(serverPlayer);
                        return TypedActionResult.success(stack);
                    }
                }
                case DIOS_BONE -> {
                    data.bizarre$setDioBoneSteps(data.bizarre$getDioBoneSteps() + 2);
                    data.bizarre$setWorthiness(5);
                    stack.decrement(1);
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.dio_bone_absorbed", data.bizarre$getDioBoneSteps()).formatted(Formatting.DARK_PURPLE, Formatting.BOLD), false);
                    ModNetworking.syncToClient(serverPlayer);
                    return TypedActionResult.success(stack);
                }
                case GREEN_BABY -> {
                    if (current == StandType.WHITESNAKE) {
                        data.bizarre$setStand(StandType.C_MOON);
                        stack.decrement(1);
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", StandType.C_MOON.getDisplayNameRu()).formatted(Formatting.GREEN, Formatting.BOLD), false);
                        ModNetworking.syncToClient(serverPlayer);
                        return TypedActionResult.success(stack);
                    } else {
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.green_baby_need_ws").formatted(Formatting.RED), true);
                        return TypedActionResult.fail(stack);
                    }
                }
                case LOCACACA_6251 -> {
                    data.bizarre$setStand(StandType.SOFT_AND_WET_GO_BEYOND);
                    data.bizarre$setStandSummoned(true);
                    stack.decrement(1);
                    serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.stand_evolved", StandType.SOFT_AND_WET_GO_BEYOND.getDisplayNameRu()).formatted(Formatting.AQUA, Formatting.BOLD), false);
                    ModAdvancementTracker.grantAdvancement(serverPlayer, "stands/go_beyond_bubble");
                    ModNetworking.syncToClient(serverPlayer);
                    return TypedActionResult.success(stack);
                }
            }
        }
        return TypedActionResult.pass(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.bizarre_odyssey.catalyst_" + kind.name().toLowerCase()).formatted(Formatting.YELLOW));
    }
}
