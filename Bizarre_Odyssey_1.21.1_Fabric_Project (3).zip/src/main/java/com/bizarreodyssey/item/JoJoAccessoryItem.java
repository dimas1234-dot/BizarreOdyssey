package com.bizarreodyssey.item;

import com.bizarreodyssey.registry.ModAdvancementTracker;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

public class JoJoAccessoryItem extends ArmorItem {
    private final String accessoryKey;

    public JoJoAccessoryItem(RegistryEntry<ArmorMaterial> material, Type type, Settings settings, String accessoryKey) {
        super(material, type, settings);
        this.accessoryKey = accessoryKey;
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, world, entity, slot, selected);
        if (!world.isClient && entity instanceof ServerPlayerEntity player && world.getTime() % 40 == 0) {
            ItemStack head = player.getEquippedStack(EquipmentSlot.HEAD);
            ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
            if (head == stack || chest == stack) {
                switch (accessoryKey) {
                    case "jotaro_cap" -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 80, 0, true, false));
                    case "dio_headband" -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 80, 0, true, false));
                    case "kakyoin_shades" -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 240, 0, true, false));
                    case "gyro_hat" -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 80, 0, true, false));
                    case "kira_tie" -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 80, 1, true, false));
                    case "giorno_brooch" -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 80, 0, true, false));
                    case "red_stone_aja" -> {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 80, 0, true, false));
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 80, 1, true, false));
                    }
                }
                ModAdvancementTracker.grantAdvancement(player, "easter_eggs/drip_over_heaven");
            }
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.bizarre_odyssey.accessory_" + accessoryKey).formatted(Formatting.GOLD));
    }
}
