package com.bizarreodyssey.network;

import com.bizarreodyssey.BizarreOdysseyMod;
import com.bizarreodyssey.spec.SpecCombatExecutor;
import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.stand.StandCombatExecutor;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;

public class ModNetworking {

    public record StandActionC2SPayload(int actionId) implements CustomPayload {
        public static final Id<StandActionC2SPayload> ID = new Id<>(BizarreOdysseyMod.id("stand_action_c2s"));
        public static final PacketCodec<RegistryByteBuf, StandActionC2SPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, StandActionC2SPayload::actionId,
                StandActionC2SPayload::new
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record SyncPlayerDataS2CPayload(
            String standId,
            String specId,
            boolean summoned,
            int worthiness,
            int energy,
            int storyStage,
            int storyKills,
            int cd0, int cd1, int cd2, int cd3, int cd4
    ) implements CustomPayload {
        public static final Id<SyncPlayerDataS2CPayload> ID = new Id<>(BizarreOdysseyMod.id("sync_player_data_s2c"));
        public static final PacketCodec<RegistryByteBuf, SyncPlayerDataS2CPayload> CODEC = PacketCodec.of(
                (value, buf) -> {
                    buf.writeString(value.standId());
                    buf.writeString(value.specId());
                    buf.writeBoolean(value.summoned());
                    buf.writeVarInt(value.worthiness());
                    buf.writeVarInt(value.energy());
                    buf.writeVarInt(value.storyStage());
                    buf.writeVarInt(value.storyKills());
                    buf.writeVarInt(value.cd0());
                    buf.writeVarInt(value.cd1());
                    buf.writeVarInt(value.cd2());
                    buf.writeVarInt(value.cd3());
                    buf.writeVarInt(value.cd4());
                },
                buf -> new SyncPlayerDataS2CPayload(
                        buf.readString(),
                        buf.readString(),
                        buf.readBoolean(),
                        buf.readVarInt(),
                        buf.readVarInt(),
                        buf.readVarInt(),
                        buf.readVarInt(),
                        buf.readVarInt(),
                        buf.readVarInt(),
                        buf.readVarInt(),
                        buf.readVarInt(),
                        buf.readVarInt()
                )
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static void registerCommon() {
        PayloadTypeRegistry.playC2S().register(StandActionC2SPayload.ID, StandActionC2SPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncPlayerDataS2CPayload.ID, SyncPlayerDataS2CPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(StandActionC2SPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            context.server().execute(() -> {
                int action = payload.actionId();
                if (action == 0) {
                    StandCombatExecutor.toggleStandSummon(player);
                } else if (action >= 1 && action <= 4) {
                    StandCombatExecutor.executeStandSkill(player, action);
                } else if (action >= 5 && action <= 7) {
                    SpecCombatExecutor.executeSpecSkill(player, action - 4);
                }
            });
        });
    }

    public static void syncToClient(ServerPlayerEntity player) {
        if (player instanceof IJoJoPlayerData data) {
            ServerPlayNetworking.send(player, new SyncPlayerDataS2CPayload(
                    data.bizarre$getStand().getId(),
                    data.bizarre$getSpec().getId(),
                    data.bizarre$isStandSummoned(),
                    data.bizarre$getWorthiness(),
                    data.bizarre$getStandEnergy(),
                    data.bizarre$getStoryStage(),
                    data.bizarre$getStoryKillProgress(),
                    data.bizarre$getCooldown(0),
                    data.bizarre$getCooldown(1),
                    data.bizarre$getCooldown(2),
                    data.bizarre$getCooldown(3),
                    data.bizarre$getCooldown(4)
            ));
        }
    }
}
