package com.bizarreodyssey.spec;

import com.bizarreodyssey.entity.StandEntity;
import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class SpecCombatExecutor {

    public static void executeSpecSkill(ServerPlayerEntity player, int specMoveIndex) {
        if (!(player instanceof IJoJoPlayerData data)) return;
        SpecType spec = data.bizarre$getSpec();
        if (spec == SpecType.NONE) {
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.no_spec").formatted(Formatting.RED), true);
            return;
        }

        int cdSlot = 4 + (specMoveIndex - 1);
        if (data.bizarre$getCooldown(cdSlot) > 0) {
            int sec = (data.bizarre$getCooldown(cdSlot) + 19) / 20;
            player.sendMessage(Text.translatable("msg.bizarre_odyssey.cooldown_wait", sec).formatted(Formatting.RED), true);
            return;
        }

        data.bizarre$setCooldown(cdSlot, 100); // 5s spec cooldown
        ServerWorld world = player.getServerWorld();
        Vec3d look = player.getRotationVec(1.0f);
        Box box = player.getBoundingBox().stretch(look.multiply(5.5)).expand(2.0);
        List<LivingEntity> targets = world.getEntitiesByClass(LivingEntity.class, box,
                e -> e != player && !(e instanceof StandEntity) && e.isAlive());

        String moveTitle = switch (specMoveIndex) {
            case 1 -> spec.getMove1Name();
            case 2 -> spec.getMove2Name();
            default -> spec.getMove3Name();
        };

        switch (spec) {
            case HAMON -> {
                for (LivingEntity target : targets) {
                    target.damage(world.getDamageSources().playerAttack(player), 12.0f + specMoveIndex * 3.0f);
                    target.setOnFireFor(5);
                }
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 1));
                world.spawnParticles(ParticleTypes.FLAME, player.getX() + look.x * 2.0, player.getY() + 1.1, player.getZ() + look.z * 2.0, 30, 0.5, 0.5, 0.5, 0.08);
                world.playSound(null, player.getBlockPos(), SoundEvents.BLOCK_FIRE_AMBIENT, SoundCategory.PLAYERS, 1.2f, 1.4f);
            }
            case VAMPIRISM -> {
                for (LivingEntity target : targets) {
                    target.damage(world.getDamageSources().magic(), 13.0f + specMoveIndex * 3.5f);
                    if (specMoveIndex == 1) {
                        player.heal(8.0f);
                    } else if (specMoveIndex == 2) {
                        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 140, 4));
                    }
                }
                world.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, player.getX() + look.x * 2.0, player.getY() + 1.2, player.getZ() + look.z * 2.0, 20, 0.4, 0.4, 0.4, 0.1);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PHANTOM_BITE, SoundCategory.PLAYERS, 1.2f, 0.7f);
            }
            case BOXING -> {
                for (LivingEntity target : targets) {
                    target.damage(world.getDamageSources().playerAttack(player), 14.0f + specMoveIndex * 2.5f);
                    target.setVelocity(look.x * 0.9, 0.45, look.z * 0.9);
                    target.velocityModified = true;
                    if (specMoveIndex == 2) {
                        target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 80, 0));
                    }
                }
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 120, 1));
                world.spawnParticles(ParticleTypes.CRIT, player.getX() + look.x * 1.8, player.getY() + 1.2, player.getZ() + look.z * 1.8, 30, 0.5, 0.5, 0.5, 0.2);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, SoundCategory.PLAYERS, 1.3f, 0.8f);
            }
            case SPIN -> {
                for (LivingEntity target : targets) {
                    target.damage(world.getDamageSources().magic(), 14.5f + specMoveIndex * 3.0f);
                }
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 140, 1));
                world.spawnParticles(ParticleTypes.COMPOSTER, player.getX() + look.x * 2.5, player.getY() + 1.2, player.getZ() + look.z * 2.5, 35, 0.6, 0.6, 0.6, 0.1);
                world.playSound(null, player.getBlockPos(), SoundEvents.ITEM_TRIDENT_THROW.value(), SoundCategory.PLAYERS, 1.2f, 1.3f);
            }
            case CYBORG -> {
                for (LivingEntity target : targets) {
                    target.damage(world.getDamageSources().playerAttack(player), 15.0f + specMoveIndex * 3.5f);
                    target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 160, 0));
                }
                world.spawnParticles(ParticleTypes.FLASH, player.getX() + look.x * 2.5, player.getY() + 1.2, player.getZ() + look.z * 2.5, 2, 0.2, 0.2, 0.2, 0.0);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_REPAIR, SoundCategory.PLAYERS, 1.2f, 1.4f);
            }
            default -> {}
        }

        player.sendMessage(Text.literal("[" + spec.getNameRu() + "] " + moveTitle + "!").formatted(spec.getColor(), Formatting.BOLD), true);
        ModNetworking.syncToClient(player);
    }
}
