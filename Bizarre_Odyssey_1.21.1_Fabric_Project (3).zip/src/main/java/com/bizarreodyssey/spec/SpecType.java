package com.bizarreodyssey.spec;

import net.minecraft.util.Formatting;

public enum SpecType {
    NONE("none", "No Spec", "Без Спека", Formatting.GRAY,
            "No Spec Move 1", "No Spec Move 2", "No Spec Ultimate", 0.0f),
    HAMON("hamon", "Hamon (Ripple)", "Хамон (Пульсация Солнца)", Formatting.GOLD,
            "Zoom Punch", "Scarlet Overdrive (Ignite)", "Sunlight Yellow Overdrive!", 0.15f),
    VAMPIRISM("vampirism", "Vampirism (Stone Mask)", "Вампиризм (Каменная Маска)", Formatting.DARK_RED,
            "Life Drain Grab", "Vaporization Freeze (HINJAKU!)", "Space Ripper Stingy Eyes!", 0.20f),
    BOXING("boxing", "Boxing Style", "Бокс (Стиль YBA)", Formatting.RED,
            "Jawbreaker (Guard Break)", "Eye Gouge (Blind)", "Fist Barrage + Tough Skin", 0.25f),
    SPIN("spin", "Golden Spin (Zeppelin)", "Золотое Вращение (Спин)", Formatting.GREEN,
            "Steel Ball Throw", "Multi-Steel Ball Ricochet", "Golden Skin Barrier + Ball Breaker", 0.18f),
    CYBORG("cyborg", "German Science (Stroheim)", "Немецкая Наука (Киборг)", Formatting.AQUA,
            "Abdominal Machine Gun (600 RPM)", "UV Floodlight Beam (Anti-Vampire)", "SEKAI ICHI Overcharge Cannon", 0.22f);

    private final String id;
    private final String nameEn;
    private final String nameRu;
    private final Formatting color;
    private final String move1Name;
    private final String move2Name;
    private final String move3Name;
    private final float damageReduction;

    SpecType(String id, String nameEn, String nameRu, Formatting color,
             String move1Name, String move2Name, String move3Name, float damageReduction) {
        this.id = id;
        this.nameEn = nameEn;
        this.nameRu = nameRu;
        this.color = color;
        this.move1Name = move1Name;
        this.move2Name = move2Name;
        this.move3Name = move3Name;
        this.damageReduction = damageReduction;
    }

    public String getId() { return id; }
    public String getNameEn() { return nameEn; }
    public String getNameRu() { return nameRu; }
    public Formatting getColor() { return color; }
    public String getMove1Name() { return move1Name; }
    public String getMove2Name() { return move2Name; }
    public String getMove3Name() { return move3Name; }
    public float getDamageReduction() { return damageReduction; }

    public static SpecType byId(String id) {
        for (SpecType spec : values()) {
            if (spec.id.equalsIgnoreCase(id)) return spec;
        }
        return NONE;
    }
}
