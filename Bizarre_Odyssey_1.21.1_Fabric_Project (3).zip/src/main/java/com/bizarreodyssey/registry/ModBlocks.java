package com.bizarreodyssey.registry;

import com.bizarreodyssey.BizarreOdysseyMod;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ModBlocks {
    public static final Block METEORITE_ORE = registerBlock("meteorite_ore",
            new Block(AbstractBlock.Settings.copy(Blocks.ANCIENT_DEBRIS).strength(6.0f, 1200.0f).requiresTool().sounds(BlockSoundGroup.ANCIENT_DEBRIS)));

    public static final Block METEORITE_IRON_BLOCK = registerBlock("meteorite_iron_block",
            new Block(AbstractBlock.Settings.copy(Blocks.NETHERITE_BLOCK).strength(8.0f, 1200.0f).requiresTool()));

    public static final Block MORIOH_PAVEMENT = registerBlock("morioh_pavement",
            new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_ANDESITE).strength(2.5f, 6.0f)));

    public static final Block CAIRO_SANDSTONE_PILLAR = registerBlock("cairo_sandstone_pillar",
            new Block(AbstractBlock.Settings.copy(Blocks.CHISELED_SANDSTONE).strength(3.0f, 8.0f)));

    public static final Block DEVILS_PALM_SAND = registerBlock("devils_palm_sand",
            new Block(AbstractBlock.Settings.copy(Blocks.SAND).strength(1.5f, 4.0f).luminance(state -> 4)));

    public static final Block WALL_EYES_STONE = registerBlock("wall_eyes_stone",
            new Block(AbstractBlock.Settings.copy(Blocks.TUFF).strength(3.5f, 9.0f).luminance(state -> 6)));

    public static final Block ANGELO_ROCK = registerBlock("angelo_rock",
            new Block(AbstractBlock.Settings.copy(Blocks.STONE).strength(4.0f, 12.0f)) {
                @Override
                protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
                    if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
                        serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.yo_angelo").formatted(Formatting.AQUA, Formatting.BOLD), false);
                        world.playSound(null, pos, SoundEvents.ENTITY_VILLAGER_AMBIENT, SoundCategory.BLOCKS, 1.0f, 0.6f);
                        ModAdvancementTracker.grantAdvancement(serverPlayer, "easter_eggs/yo_angelo");
                    }
                    return ActionResult.SUCCESS;
                }
            });

    public static final Block HEAVEN_ALTAR = registerBlock("heaven_altar",
            new Block(AbstractBlock.Settings.copy(Blocks.CRYING_OBSIDIAN).strength(10.0f, 1200.0f).luminance(state -> 12)) {
                @Override
                protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
                    if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer && player instanceof IJoJoPlayerData data) {
                        if (pos.getY() >= 180 && data.bizarre$getDioBoneSteps() >= 4) {
                            ServerWorld sw = serverPlayer.getServerWorld();
                            sw.spawnParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5, 80, 1.0, 2.0, 1.0, 0.15);
                            sw.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1.5f, 1.0f);
                            serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.heaven_attained").formatted(Formatting.GOLD, Formatting.BOLD), false);
                        } else {
                            serverPlayer.sendMessage(Text.translatable("msg.bizarre_odyssey.heaven_altar_hint").formatted(Formatting.YELLOW), true);
                        }
                    }
                    return ActionResult.SUCCESS;
                }
            });

    private static Block registerBlock(String name, Block block) {
        Block registered = Registry.register(Registries.BLOCK, BizarreOdysseyMod.id(name), block);
        Registry.register(Registries.ITEM, BizarreOdysseyMod.id(name), new BlockItem(registered, new Item.Settings()));
        return registered;
    }

    public static void registerAll() {
        BizarreOdysseyMod.LOGGER.info("Registered Bizarre Odyssey Blocks.");
    }
}
