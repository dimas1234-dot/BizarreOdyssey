package com.bizarreodyssey.registry;

import com.bizarreodyssey.BizarreOdysseyMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
    public static final SoundEvent STAND_SUMMON = register("stand_summon");
    public static final SoundEvent ORA_BARRAGE = register("ora_barrage");
    public static final SoundEvent MUDA_BARRAGE = register("muda_barrage");
    public static final SoundEvent DORA_BARRAGE = register("dora_barrage");
    public static final SoundEvent TIME_STOP = register("time_stop");
    public static final SoundEvent TIME_ERASE = register("time_erase");
    public static final SoundEvent CHUMIMIN = register("chumimin");
    public static final SoundEvent HAMON_BREATH = register("hamon_breath");

    private static SoundEvent register(String name) {
        Identifier id = BizarreOdysseyMod.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void registerAll() {
        BizarreOdysseyMod.LOGGER.info("Registered Bizarre Odyssey Sound Events.");
    }
}
