package com.bizarreodyssey.registry;

import com.bizarreodyssey.BizarreOdysseyMod;
import com.bizarreodyssey.item.*;
import com.bizarreodyssey.spec.SpecType;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Rarity;

public class ModItems {
    // Arrows & Fruits
    public static final Item STAND_ARROW = register("stand_arrow",
            new StandArrowItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), false, false));
    public static final Item REQUIEM_ARROW = register("requiem_arrow",
            new StandArrowItem(new Item.Settings().maxCount(4).rarity(Rarity.EPIC), true, false));
    public static final Item LUCKY_ARROW = register("lucky_arrow",
            new StandArrowItem(new Item.Settings().maxCount(4).rarity(Rarity.EPIC), false, true));

    public static final Item ROKAKAKA_FRUIT = register("rokakaka_fruit",
            new RokakakaFruitItem(new Item.Settings().maxCount(16).rarity(Rarity.UNCOMMON)
                    .food(new FoodComponent.Builder().nutrition(4).saturationModifier(0.3f).alwaysEdible().build()), false));
    public static final Item PURE_ROKAKAKA = register("pure_rokakaka",
            new RokakakaFruitItem(new Item.Settings().maxCount(8).rarity(Rarity.RARE)
                    .food(new FoodComponent.Builder().nutrition(6).saturationModifier(0.5f).alwaysEdible().build()), true));

    // Saint's Corpse Parts (Part 7)
    public static final Item SAINTS_RIB_CAGE = register("saints_rib_cage",
            new CorpsePartItem(new Item.Settings().maxCount(4).rarity(Rarity.RARE), CorpsePartItem.PartKind.RIB_CAGE));
    public static final Item SAINTS_LEFT_ARM = register("saints_left_arm",
            new CorpsePartItem(new Item.Settings().maxCount(4).rarity(Rarity.RARE), CorpsePartItem.PartKind.LEFT_ARM));
    public static final Item SAINTS_PELVIS = register("saints_pelvis",
            new CorpsePartItem(new Item.Settings().maxCount(2).rarity(Rarity.EPIC), CorpsePartItem.PartKind.PELVIS));
    public static final Item SAINTS_HEART = register("saints_heart",
            new CorpsePartItem(new Item.Settings().maxCount(2).rarity(Rarity.EPIC), CorpsePartItem.PartKind.HEART));

    // Evolution Catalysts (Parts 3-8)
    public static final Item DIOS_DIARY = register("dios_diary",
            new EvolutionCatalystItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC), EvolutionCatalystItem.CatalystKind.DIOS_DIARY));
    public static final Item DIOS_BONE = register("dios_bone",
            new EvolutionCatalystItem(new Item.Settings().maxCount(4).rarity(Rarity.RARE), EvolutionCatalystItem.CatalystKind.DIOS_BONE));
    public static final Item GREEN_BABY = register("green_baby",
            new EvolutionCatalystItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC), EvolutionCatalystItem.CatalystKind.GREEN_BABY));
    public static final Item LOCACACA_6251 = register("locacaca_6251",
            new EvolutionCatalystItem(new Item.Settings().maxCount(4).rarity(Rarity.EPIC), EvolutionCatalystItem.CatalystKind.LOCACACA_6251));

    // Spec Unlock Items (YBA Style)
    public static final Item ZEPPELIS_HAMON_WINE = register("zeppelis_hamon_wine",
            new SpecUnlockItem(new Item.Settings().maxCount(1).rarity(Rarity.RARE), SpecType.HAMON));
    public static final Item STONE_MASK = register("stone_mask",
            new SpecUnlockItem(new Item.Settings().maxCount(1).rarity(Rarity.RARE), SpecType.VAMPIRISM));
    public static final Item BOXING_GLOVES = register("boxing_gloves",
            new SpecUnlockItem(new Item.Settings().maxCount(1).rarity(Rarity.RARE), SpecType.BOXING));
    public static final Item GYROS_STEEL_BALL = register("gyros_steel_ball",
            new SpecUnlockItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC), SpecType.SPIN));
    public static final Item STROHEIM_CYBORG_CORE = register("stroheim_cyborg_core",
            new SpecUnlockItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC), SpecType.CYBORG));

    // Wearable JoJo Accessories (Hats & Chest Relics)
    public static final Item JOTARO_CAP = register("jotaro_cap",
            new JoJoAccessoryItem(ArmorMaterials.NETHERITE, ArmorItem.Type.HELMET, new Item.Settings().maxCount(1).rarity(Rarity.RARE), "jotaro_cap"));
    public static final Item DIO_HEADBAND = register("dio_headband",
            new JoJoAccessoryItem(ArmorMaterials.GOLD, ArmorItem.Type.HELMET, new Item.Settings().maxCount(1).rarity(Rarity.RARE), "dio_headband"));
    public static final Item KAKYOIN_SHADES = register("kakyoin_shades",
            new JoJoAccessoryItem(ArmorMaterials.DIAMOND, ArmorItem.Type.HELMET, new Item.Settings().maxCount(1).rarity(Rarity.RARE), "kakyoin_shades"));
    public static final Item GYRO_HAT = register("gyro_hat",
            new JoJoAccessoryItem(ArmorMaterials.DIAMOND, ArmorItem.Type.HELMET, new Item.Settings().maxCount(1).rarity(Rarity.RARE), "gyro_hat"));
    public static final Item KIRA_SKULL_TIE = register("kira_skull_tie",
            new JoJoAccessoryItem(ArmorMaterials.IRON, ArmorItem.Type.CHESTPLATE, new Item.Settings().maxCount(1).rarity(Rarity.RARE), "kira_tie"));
    public static final Item GIORNO_LADYBUG_BROOCH = register("giorno_ladybug_brooch",
            new JoJoAccessoryItem(ArmorMaterials.GOLD, ArmorItem.Type.CHESTPLATE, new Item.Settings().maxCount(1).rarity(Rarity.RARE), "giorno_brooch"));
    public static final Item RED_STONE_OF_AJA = register("red_stone_of_aja",
            new JoJoAccessoryItem(ArmorMaterials.NETHERITE, ArmorItem.Type.CHESTPLATE, new Item.Settings().maxCount(1).rarity(Rarity.EPIC), "red_stone_aja"));

    // Story Campaign & Crafting Materials
    public static final Item METEORITE_INGOT = register("meteorite_ingot",
            new Item(new Item.Settings().rarity(Rarity.UNCOMMON)));
    public static final Item STORY_JOURNAL_COMPASS = register("story_journal_compass",
            new StoryCompassItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));

    // Anime Easter Egg Items
    public static final Item COMBUSTIBLE_OOLONG_TEA = register("combustible_oolong_tea",
            new AnimeEasterEggItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), "oolong_tea"));
    public static final Item TORTURE_DANCE_BOOMBOX = register("torture_dance_boombox",
            new AnimeEasterEggItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC), "torture_boombox"));
    public static final Item TONIOS_CAPRESE_SALAD = register("tonios_caprese_salad",
            new AnimeEasterEggItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), "tonio_caprese"));
    public static final Item PANZER_TRACK_TALISMAN = register("panzer_track_talisman",
            new AnimeEasterEggItem(new Item.Settings().maxCount(1).rarity(Rarity.RARE), "panzer_track_talisman"));
    public static final Item SNEZHNAYA_DELUSION_EMBLEM = register("snezhnaya_delusion_emblem",
            new AnimeEasterEggItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC), "delusion_emblem"));
    public static final Item CURSED_FINGER_RELIC = register("cursed_finger_relic",
            new AnimeEasterEggItem(new Item.Settings().maxCount(4).rarity(Rarity.EPIC), "cursed_finger_relic"));

    public static final ItemGroup BIZARRE_ITEM_GROUP = Registry.register(
            Registries.ITEM_GROUP,
            BizarreOdysseyMod.id("bizarre_odyssey_group"),
            FabricItemGroup.builder()
                    .displayName(Text.translatable("itemGroup.bizarre_odyssey.general"))
                    .icon(() -> new ItemStack(REQUIEM_ARROW))
                    .entries((context, entries) -> {
                        entries.add(STORY_JOURNAL_COMPASS);
                        entries.add(STAND_ARROW);
                        entries.add(REQUIEM_ARROW);
                        entries.add(LUCKY_ARROW);
                        entries.add(ROKAKAKA_FRUIT);
                        entries.add(PURE_ROKAKAKA);
                        entries.add(SAINTS_RIB_CAGE);
                        entries.add(SAINTS_LEFT_ARM);
                        entries.add(SAINTS_PELVIS);
                        entries.add(SAINTS_HEART);
                        entries.add(DIOS_DIARY);
                        entries.add(DIOS_BONE);
                        entries.add(GREEN_BABY);
                        entries.add(LOCACACA_6251);
                        entries.add(ZEPPELIS_HAMON_WINE);
                        entries.add(STONE_MASK);
                        entries.add(BOXING_GLOVES);
                        entries.add(GYROS_STEEL_BALL);
                        entries.add(STROHEIM_CYBORG_CORE);
                        entries.add(JOTARO_CAP);
                        entries.add(DIO_HEADBAND);
                        entries.add(KAKYOIN_SHADES);
                        entries.add(GYRO_HAT);
                        entries.add(KIRA_SKULL_TIE);
                        entries.add(GIORNO_LADYBUG_BROOCH);
                        entries.add(RED_STONE_OF_AJA);
                        entries.add(COMBUSTIBLE_OOLONG_TEA);
                        entries.add(TORTURE_DANCE_BOOMBOX);
                        entries.add(TONIOS_CAPRESE_SALAD);
                        entries.add(PANZER_TRACK_TALISMAN);
                        entries.add(SNEZHNAYA_DELUSION_EMBLEM);
                        entries.add(CURSED_FINGER_RELIC);
                        entries.add(METEORITE_INGOT);
                        entries.add(ModBlocks.METEORITE_ORE);
                        entries.add(ModBlocks.METEORITE_IRON_BLOCK);
                        entries.add(ModBlocks.MORIOH_PAVEMENT);
                        entries.add(ModBlocks.CAIRO_SANDSTONE_PILLAR);
                        entries.add(ModBlocks.DEVILS_PALM_SAND);
                        entries.add(ModBlocks.WALL_EYES_STONE);
                        entries.add(ModBlocks.ANGELO_ROCK);
                        entries.add(ModBlocks.HEAVEN_ALTAR);
                    })
                    .build()
    );

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, BizarreOdysseyMod.id(name), item);
    }

    public static void registerAll() {
        BizarreOdysseyMod.LOGGER.info("Registered Bizarre Odyssey Items and Creative Tab.");
    }
}
