package com.bizarreodyssey.registry;

import com.bizarreodyssey.BizarreOdysseyMod;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.advancement.AdvancementProgress;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class ModAdvancementTracker {
    /**
     * Grants a custom Bizarre Odyssey advancement ONLY when exact gameplay/story conditions are verified in code.
     */
    public static void grantAdvancement(ServerPlayerEntity player, String path) {
        if (player == null || player.getServer() == null) return;
        MinecraftServer server = player.getServer();
        Identifier id = BizarreOdysseyMod.id(path);
        AdvancementEntry entry = server.getAdvancementLoader().get(id);
        if (entry != null) {
            AdvancementProgress progress = player.getAdvancementTracker().getProgress(entry);
            if (!progress.isDone()) {
                for (String criterion : progress.getUnobtainedCriteria()) {
                    player.getAdvancementTracker().grantCriterion(entry, criterion);
                }
            }
        }
    }
}
