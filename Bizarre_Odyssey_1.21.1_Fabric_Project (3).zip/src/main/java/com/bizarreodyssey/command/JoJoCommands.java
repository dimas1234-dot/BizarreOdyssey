package com.bizarreodyssey.command;

import com.bizarreodyssey.network.ModNetworking;
import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.story.StoryCampaignManager;
import com.bizarreodyssey.util.IJoJoPlayerData;
import com.bizarreodyssey.world.JoJoStructureBuilder;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class JoJoCommands {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("jojo")
                .then(CommandManager.literal("stand")
                        .then(CommandManager.argument("stand_id", StringArgumentType.word())
                                .executes(ctx -> {
                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                    String id = StringArgumentType.getString(ctx, "stand_id");
                                    StandType type = StandType.byId(id);
                                    if (player instanceof IJoJoPlayerData data) {
                                        data.bizarre$setStand(type);
                                        data.bizarre$setWorthiness(5);
                                        ModNetworking.syncToClient(player);
                                        player.sendMessage(Text.literal("Установлен Стенд: " + type.getDisplayNameRu()).formatted(Formatting.GOLD), false);
                                    }
                                    return 1;
                                })))
                .then(CommandManager.literal("spec")
                        .then(CommandManager.argument("spec_id", StringArgumentType.word())
                                .executes(ctx -> {
                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                    String id = StringArgumentType.getString(ctx, "spec_id");
                                    SpecType spec = SpecType.byId(id);
                                    if (player instanceof IJoJoPlayerData data) {
                                        data.bizarre$setSpec(spec);
                                        ModNetworking.syncToClient(player);
                                        player.sendMessage(Text.literal("Установлен Спек: " + spec.getNameRu()).formatted(Formatting.AQUA), false);
                                    }
                                    return 1;
                                })))
                .then(CommandManager.literal("story")
                        .then(CommandManager.argument("stage", IntegerArgumentType.integer(0, 16))
                                .executes(ctx -> {
                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                    int stage = IntegerArgumentType.getInteger(ctx, "stage");
                                    if (player instanceof IJoJoPlayerData data) {
                                        data.bizarre$setStoryStage(stage);
                                        data.bizarre$setStoryKillProgress(0);
                                        ModNetworking.syncToClient(player);
                                        StoryCampaignManager.printCurrentObjective(player);
                                    }
                                    return 1;
                                })))
                .then(CommandManager.literal("spawn_structure")
                        .then(CommandManager.argument("structure_name", StringArgumentType.word())
                                .executes(ctx -> {
                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                    String name = StringArgumentType.getString(ctx, "structure_name");
                                    JoJoStructureBuilder.buildStructureAt(player.getServerWorld(), player.getBlockPos().add(6, 0, 6), name);
                                    player.sendMessage(Text.literal("Сгенерирована структура JoJo: " + name).formatted(Formatting.GREEN), false);
                                    return 1;
                                }))));
    }
}
