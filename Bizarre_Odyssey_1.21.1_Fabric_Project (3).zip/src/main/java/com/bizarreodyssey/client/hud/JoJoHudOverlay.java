package com.bizarreodyssey.client.hud;

import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.story.StoryCampaignManager;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class JoJoHudOverlay implements HudRenderCallback {

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;
        if (!(client.player instanceof IJoJoPlayerData data)) return;

        TextRenderer tr = client.textRenderer;
        StandType stand = data.bizarre$getStand();
        SpecType spec = data.bizarre$getSpec();

        int x = 10;
        int y = 10;

        // Background Panel
        context.fill(x - 4, y - 4, x + 235, y + 86, 0x90120A1E);
        context.drawBorder(x - 4, y - 4, 239, 90, 0xFFD4AF37);

        // Stand & Spec Header
        String summonedTag = data.bizarre$isStandSummoned() ? " [АКТИВЕН: V]" : " [СКРЫТ: V]";
        context.drawTextWithShadow(tr, Text.literal("★ СТЕНД: " + stand.getDisplayNameRu() + summonedTag).formatted(stand.getFormatting(), Formatting.BOLD), x, y, 0xFFFFFF);
        context.drawTextWithShadow(tr, Text.literal("✦ СПЕК: " + spec.getNameRu() + " | Достоинство: " + data.bizarre$getWorthiness() + "/5").formatted(spec.getColor()), x, y + 12, 0xFFFFFF);

        // Story Chapter Tracker
        String chapterLine = StoryCampaignManager.getShortHudObjective(data.bizarre$getStoryStage(), data.bizarre$getStoryKillProgress());
        context.drawTextWithShadow(tr, Text.literal("📜 " + chapterLine).formatted(Formatting.YELLOW), x, y + 24, 0xFFFFFF);

        // Skill Cooldown Bars (Z, X, C, R + Spec G)
        renderCooldownLine(context, tr, x, y + 38, "[Z] " + stand.getSkill1Name(), data.bizarre$getCooldown(0), 80, stand.getAuraColor());
        renderCooldownLine(context, tr, x, y + 49, "[X] " + stand.getSkill2Name(), data.bizarre$getCooldown(1), 140, stand.getAuraColor());
        renderCooldownLine(context, tr, x, y + 60, "[C] " + stand.getSkill3Name(), data.bizarre$getCooldown(2), 180, stand.getAuraColor());
        renderCooldownLine(context, tr, x, y + 71, "[R] ULT: " + stand.getUltimateName(), data.bizarre$getCooldown(3), 400, 0xFFD700);

        // Menacing Kanji (ゴゴゴゴ) when Stand is Summoned
        if (data.bizarre$isStandSummoned()) {
            long time = client.world != null ? client.world.getTime() : 0;
            int floatOffset = (int) (Math.sin(time * 0.15) * 4);
            context.drawTextWithShadow(tr, Text.literal("ゴ ゴ ゴ ゴ").formatted(Formatting.DARK_PURPLE, Formatting.BOLD), x + 242, y + 10 + floatOffset, 0xFFAA00FF);
        }
    }

    private void renderCooldownLine(DrawContext context, TextRenderer tr, int x, int y, String label, int cd, int maxCd, int color) {
        String status = cd > 0 ? String.format(" (%.1fs)", cd / 20.0f) : " [ГОТОВО]";
        int textColor = cd > 0 ? 0xFFAAAAAA : 0xFF55FF55;
        String clipped = label.length() > 28 ? label.substring(0, 28) + ".." : label;
        context.drawTextWithShadow(tr, clipped + status, x, y, textColor);
    }
}
