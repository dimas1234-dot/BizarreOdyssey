package com.bizarreodyssey.client.render;

import com.bizarreodyssey.BizarreOdysseyMod;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

public class StoryActorRenderer<T extends MobEntity> extends BipedEntityRenderer<T, BipedEntityModel<T>> {
    private final Identifier texture;

    public StoryActorRenderer(EntityRendererFactory.Context ctx, String texName) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER)), 0.5f);
        this.texture = BizarreOdysseyMod.id("textures/entity/" + texName + ".png");
    }

    @Override
    public Identifier getTexture(T entity) {
        return texture;
    }
}
