package com.bizarreodyssey.client.render;

import com.bizarreodyssey.BizarreOdysseyMod;
import com.bizarreodyssey.entity.StandEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public class StandEntityRenderer extends MobEntityRenderer<StandEntity, StandEntityModel> {
    private static final Identifier DEFAULT_TEXTURE = BizarreOdysseyMod.id("textures/entity/stand_spirit.png");

    public StandEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new StandEntityModel(context.getPart(StandEntityModel.LAYER_LOCATION)), 0.0f);
    }

    @Override
    public Identifier getTexture(StandEntity entity) {
        return DEFAULT_TEXTURE;
    }

    @Nullable
    @Override
    protected RenderLayer getRenderLayer(StandEntity entity, boolean showBody, boolean translucent, boolean showOutline) {
        return RenderLayer.getEntityTranslucentEmissive(getTexture(entity));
    }
}
