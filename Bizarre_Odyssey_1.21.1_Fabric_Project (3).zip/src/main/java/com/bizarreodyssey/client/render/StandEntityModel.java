package com.bizarreodyssey.client.render;

import com.bizarreodyssey.BizarreOdysseyMod;
import com.bizarreodyssey.entity.StandEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class StandEntityModel extends EntityModel<StandEntity> {
    public static final EntityModelLayer LAYER_LOCATION = new EntityModelLayer(BizarreOdysseyMod.id("stand_spirit"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart torso;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart auraHalo;

    public StandEntityModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.torso = root.getChild("torso");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.auraHalo = root.getChild("aura_halo");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        // Head + Stand Crown/Crest
        ModelPartData head = root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new Dilation(0.2F))
                .uv(32, 0).cuboid(-4.5F, -11.0F, -4.5F, 9.0F, 4.0F, 9.0F, new Dilation(0.1F)),
                ModelTransform.pivot(0.0F, 0.0F, 0.0F));

        // Muscular Torso + Golden Shoulder Pauldrons
        root.addChild("torso", ModelPartBuilder.create()
                .uv(16, 16).cuboid(-4.5F, 0.0F, -2.5F, 9.0F, 12.0F, 5.0F, new Dilation(0.25F))
                .uv(0, 32).cuboid(-8.5F, -1.5F, -3.0F, 4.0F, 4.0F, 6.0F, new Dilation(0.2F))
                .uv(20, 32).cuboid(4.5F, -1.5F, -3.0F, 4.0F, 4.0F, 6.0F, new Dilation(0.2F)),
                ModelTransform.pivot(0.0F, 0.0F, 0.0F));

        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(40, 16).cuboid(-3.5F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.2F)),
                ModelTransform.pivot(-5.5F, 2.0F, 0.0F));

        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(40, 16).mirrored().cuboid(-0.5F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.2F)),
                ModelTransform.pivot(5.5F, 2.0F, 0.0F));

        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(0, 16).cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.1F)),
                ModelTransform.pivot(-2.2F, 12.0F, 0.0F));

        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 16).mirrored().cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.1F)),
                ModelTransform.pivot(2.2F, 12.0F, 0.0F));

        // Floating Requiem / Over Heaven Back Crest
        root.addChild("aura_halo", ModelPartBuilder.create()
                .uv(0, 44).cuboid(-6.0F, -6.0F, 3.5F, 12.0F, 12.0F, 1.0F, new Dilation(0.0F)),
                ModelTransform.pivot(0.0F, 4.0F, 0.0F));

        return TexturedModelData.of(modelData, 64, 64);
    }

    @Override
    public void setAngles(StandEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.head.yaw = headYaw * ((float) Math.PI / 180F);
        this.head.pitch = headPitch * ((float) Math.PI / 180F);
        this.auraHalo.roll = animationProgress * 0.08F;

        if (entity.getBarrageTicks() > 0) {
            // High-speed ORA / MUDA Barrage Rush Pose
            this.rightArm.pitch = -1.5F + MathHelper.sin(animationProgress * 2.8F) * 0.85F;
            this.leftArm.pitch = -1.5F - MathHelper.sin(animationProgress * 2.8F) * 0.85F;
            this.rightArm.yaw = 0.15F;
            this.leftArm.yaw = -0.15F;
        } else {
            // Iconic JoJo Menacing Floating Pose
            this.rightArm.pitch = -0.35F + MathHelper.cos(animationProgress * 0.09F) * 0.1F;
            this.leftArm.pitch = -0.55F - MathHelper.sin(animationProgress * 0.09F) * 0.1F;
            this.rightArm.yaw = 0.0F;
            this.leftArm.yaw = 0.0F;
        }

        this.rightLeg.pitch = 0.25F + MathHelper.sin(animationProgress * 0.07F) * 0.05F;
        this.leftLeg.pitch = 0.45F - MathHelper.sin(animationProgress * 0.07F) * 0.05F;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, int color) {
        this.root.render(matrices, vertices, light, overlay, color);
    }
}
