package com.bizarreodyssey.mixin;

import com.bizarreodyssey.stand.TimeStopManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityTimeStopMixin extends Entity {
    public LivingEntityTimeStopMixin(EntityType<?> type, World world) {
        super(type, world);
    }

    @Inject(method = "tickMovement", at = @At("HEAD"), cancellable = true)
    private void onTickMovement(CallbackInfo ci) {
        if (TimeStopManager.isEntityFrozen(this)) {
            this.setVelocity(Vec3d.ZERO);
            this.velocityModified = true;
            ci.cancel();
        }
    }
}
