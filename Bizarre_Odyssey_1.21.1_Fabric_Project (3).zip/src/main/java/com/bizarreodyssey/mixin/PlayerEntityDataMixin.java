package com.bizarreodyssey.mixin;

import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityDataMixin implements IJoJoPlayerData {
    @Unique private String bizarre$standId = "none";
    @Unique private String bizarre$specId = "none";
    @Unique private boolean bizarre$standSummoned = false;
    @Unique private int bizarre$worthiness = 1;
    @Unique private int bizarre$standEnergy = 100;
    @Unique private int bizarre$storyStage = 0;
    @Unique private int bizarre$storyKillProgress = 0;
    @Unique private int bizarre$dioBoneSteps = 0;
    @Unique private final int[] bizarre$cooldowns = new int[8];

    @Override
    public StandType bizarre$getStand() {
        return StandType.byId(this.bizarre$standId);
    }

    @Override
    public void bizarre$setStand(StandType stand) {
        this.bizarre$standId = stand == null ? "none" : stand.getId();
    }

    @Override
    public SpecType bizarre$getSpec() {
        return SpecType.byId(this.bizarre$specId);
    }

    @Override
    public void bizarre$setSpec(SpecType spec) {
        this.bizarre$specId = spec == null ? "none" : spec.getId();
    }

    @Override
    public boolean bizarre$isStandSummoned() {
        return this.bizarre$standSummoned && bizarre$getStand() != StandType.NONE;
    }

    @Override
    public void bizarre$setStandSummoned(boolean summoned) {
        this.bizarre$standSummoned = summoned;
    }

    @Override
    public int bizarre$getWorthiness() {
        return this.bizarre$worthiness;
    }

    @Override
    public void bizarre$setWorthiness(int worthiness) {
        this.bizarre$worthiness = Math.max(0, Math.min(5, worthiness));
    }

    @Override
    public int bizarre$getStandEnergy() {
        return this.bizarre$standEnergy;
    }

    @Override
    public void bizarre$setStandEnergy(int energy) {
        this.bizarre$standEnergy = Math.max(0, Math.min(100, energy));
    }

    @Override
    public int bizarre$getStoryStage() {
        return this.bizarre$storyStage;
    }

    @Override
    public void bizarre$setStoryStage(int stage) {
        this.bizarre$storyStage = Math.max(0, stage);
    }

    @Override
    public int bizarre$getStoryKillProgress() {
        return this.bizarre$storyKillProgress;
    }

    @Override
    public void bizarre$setStoryKillProgress(int progress) {
        this.bizarre$storyKillProgress = Math.max(0, progress);
    }

    @Override
    public int bizarre$getDioBoneSteps() {
        return this.bizarre$dioBoneSteps;
    }

    @Override
    public void bizarre$setDioBoneSteps(int steps) {
        this.bizarre$dioBoneSteps = Math.max(0, Math.min(4, steps));
    }

    @Override
    public int bizarre$getCooldown(int slot) {
        if (slot < 0 || slot >= bizarre$cooldowns.length) return 0;
        return bizarre$cooldowns[slot];
    }

    @Override
    public void bizarre$setCooldown(int slot, int ticks) {
        if (slot >= 0 && slot < bizarre$cooldowns.length) {
            bizarre$cooldowns[slot] = Math.max(0, ticks);
        }
    }

    @Override
    public void bizarre$tickCooldowns() {
        for (int i = 0; i < bizarre$cooldowns.length; i++) {
            if (bizarre$cooldowns[i] > 0) {
                bizarre$cooldowns[i]--;
            }
        }
        if (this.bizarre$standEnergy < 100) {
            this.bizarre$standEnergy = Math.min(100, this.bizarre$standEnergy + 1);
        }
    }

    @Override
    public NbtCompound bizarre$writeData() {
        NbtCompound nbt = new NbtCompound();
        nbt.putString("StandId", this.bizarre$standId);
        nbt.putString("SpecId", this.bizarre$specId);
        nbt.putBoolean("Summoned", this.bizarre$standSummoned);
        nbt.putInt("Worthiness", this.bizarre$worthiness);
        nbt.putInt("Energy", this.bizarre$standEnergy);
        nbt.putInt("StoryStage", this.bizarre$storyStage);
        nbt.putInt("StoryKills", this.bizarre$storyKillProgress);
        nbt.putInt("DioBoneSteps", this.bizarre$dioBoneSteps);
        nbt.putIntArray("Cooldowns", this.bizarre$cooldowns);
        return nbt;
    }

    @Override
    public void bizarre$readData(NbtCompound nbt) {
        if (nbt.contains("StandId")) this.bizarre$standId = nbt.getString("StandId");
        if (nbt.contains("SpecId")) this.bizarre$specId = nbt.getString("SpecId");
        if (nbt.contains("Summoned")) this.bizarre$standSummoned = nbt.getBoolean("Summoned");
        if (nbt.contains("Worthiness")) this.bizarre$worthiness = nbt.getInt("Worthiness");
        if (nbt.contains("Energy")) this.bizarre$standEnergy = nbt.getInt("Energy");
        if (nbt.contains("StoryStage")) this.bizarre$storyStage = nbt.getInt("StoryStage");
        if (nbt.contains("StoryKills")) this.bizarre$storyKillProgress = nbt.getInt("StoryKills");
        if (nbt.contains("DioBoneSteps")) this.bizarre$dioBoneSteps = nbt.getInt("DioBoneSteps");
        if (nbt.contains("Cooldowns")) {
            int[] arr = nbt.getIntArray("Cooldowns");
            for (int i = 0; i < Math.min(arr.length, bizarre$cooldowns.length); i++) {
                bizarre$cooldowns[i] = arr[i];
            }
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteNbt(NbtCompound nbt, CallbackInfo ci) {
        nbt.put("BizarreOdysseyData", bizarre$writeData());
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadNbt(NbtCompound nbt, CallbackInfo ci) {
        if (nbt.contains("BizarreOdysseyData")) {
            bizarre$readData(nbt.getCompound("BizarreOdysseyData"));
        }
    }
}
