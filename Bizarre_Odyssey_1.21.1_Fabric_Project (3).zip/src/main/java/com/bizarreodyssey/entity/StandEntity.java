package com.bizarreodyssey.entity;

import com.bizarreodyssey.stand.StandType;
import com.bizarreodyssey.util.IJoJoPlayerData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Arm;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Collections;
import java.util.UUID;

public class StandEntity extends PathAwareEntity {
    private static final TrackedData<String> STAND_ID = DataTracker.registerData(StandEntity.class, TrackedDataHandlerRegistry.STRING);
    private static final TrackedData<Integer> BARRAGE_TICKS = DataTracker.registerData(StandEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private UUID ownerUuid;

    public StandEntity(EntityType<? extends PathAwareEntity> entityType, World world) {
        super(entityType, world);
        this.noClip = true;
        this.setNoGravity(true);
        this.setInvulnerable(true);
    }

    public static DefaultAttributeContainer.Builder createStandAttributes() {
        return LivingEntity.createLivingAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.5)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 10.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(STAND_ID, "star_platinum");
        builder.add(BARRAGE_TICKS, 0);
    }

    public void setOwner(PlayerEntity player) {
        this.ownerUuid = player.getUuid();
        if (player instanceof IJoJoPlayerData data) {
            this.dataTracker.set(STAND_ID, data.bizarre$getStand().getId());
        }
    }

    public String getStandId() {
        return this.dataTracker.get(STAND_ID);
    }

    public void setStandId(String id) {
        this.dataTracker.set(STAND_ID, id);
    }

    public int getBarrageTicks() {
        return this.dataTracker.get(BARRAGE_TICKS);
    }

    public void triggerBarrageAnim(int ticks) {
        this.dataTracker.set(BARRAGE_TICKS, ticks);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getBarrageTicks() > 0) {
            this.dataTracker.set(BARRAGE_TICKS, this.getBarrageTicks() - 1);
        }

        if (!this.getWorld().isClient) {
            if (ownerUuid == null) {
                this.discard();
                return;
            }
            PlayerEntity owner = this.getWorld().getPlayerByUuid(ownerUuid);
            if (owner == null || !owner.isAlive() || !(owner instanceof IJoJoPlayerData data) || !data.bizarre$isStandSummoned()) {
                this.discard();
                return;
            }

            StandType stand = data.bizarre$getStand();
            if (!stand.getId().equals(getStandId())) {
                setStandId(stand.getId());
            }

            double yawRad = Math.toRadians(owner.getYaw());
            double offsetDist = this.getBarrageTicks() > 0 ? 1.15 : -0.95;
            double sideOffset = this.getBarrageTicks() > 0 ? 0.0 : 0.65;

            double targetX = owner.getX() - Math.sin(yawRad) * offsetDist + Math.cos(yawRad) * sideOffset;
            double targetY = owner.getY() + 0.35 + Math.sin(this.age * 0.12) * 0.08;
            double targetZ = owner.getZ() + Math.cos(yawRad) * offsetDist + Math.sin(yawRad) * sideOffset;

            this.refreshPositionAndAngles(targetX, targetY, targetZ, owner.getYaw(), owner.getPitch());
            this.setHeadYaw(owner.getHeadYaw());
            this.setBodyYaw(owner.getBodyYaw());
        } else {
            if (this.age % 3 == 0) {
                this.getWorld().addParticle(ParticleTypes.ENCHANT,
                        this.getX() + (random.nextDouble() - 0.5) * 0.8,
                        this.getY() + random.nextDouble() * 1.8,
                        this.getZ() + (random.nextDouble() - 0.5) * 0.8,
                        0, 0.05, 0);
            }
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public Iterable<ItemStack> getArmorItems() {
        return Collections.emptyList();
    }

    @Override
    public ItemStack getEquippedStack(EquipmentSlot slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public void equipStack(EquipmentSlot slot, ItemStack stack) {}

    @Override
    public Arm getMainArm() {
        return Arm.RIGHT;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (ownerUuid != null) nbt.putUuid("OwnerUuid", ownerUuid);
        nbt.putString("StandId", getStandId());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("OwnerUuid")) ownerUuid = nbt.getUuid("OwnerUuid");
        if (nbt.contains("StandId")) setStandId(nbt.getString("StandId"));
    }
}
