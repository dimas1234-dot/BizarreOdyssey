package com.bizarreodyssey.entity;

import com.bizarreodyssey.registry.ModAdvancementTracker;
import com.bizarreodyssey.registry.ModItems;
import com.bizarreodyssey.story.StoryCampaignManager;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class StoryBossEntity extends HostileEntity {
    private static final TrackedData<String> BOSS_TYPE = DataTracker.registerData(StoryBossEntity.class, TrackedDataHandlerRegistry.STRING);
    private final ServerBossBar bossBar;
    private int abilityCooldown = 100;

    public StoryBossEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.bossBar = new ServerBossBar(this.getDisplayName(), BossBar.Color.PURPLE, BossBar.Style.NOTCHED_10);
        this.experiencePoints = 150;
    }

    public static DefaultAttributeContainer.Builder createBossAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 280.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
                .add(EntityAttributes.GENERIC_ARMOR, 12.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.65)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(BOSS_TYPE, "dio_brando");
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.25D, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.9D));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 16.0F));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    public String getBossType() {
        return this.dataTracker.get(BOSS_TYPE);
    }

    public void configureBossType(String typeId) {
        this.dataTracker.set(BOSS_TYPE, typeId);
        switch (typeId) {
            case "cultist_minion" -> {
                this.setCustomName(Text.translatable("entity.bizarre_odyssey.cultist_minion").formatted(Formatting.RED));
                this.bossBar.setVisible(false);
            }
            case "dio_brando" -> {
                this.setCustomName(Text.translatable("entity.bizarre_odyssey.dio_brando").formatted(Formatting.GOLD, Formatting.BOLD));
                this.bossBar.setColor(BossBar.Color.YELLOW);
            }
            case "yoshikage_kira" -> {
                this.setCustomName(Text.translatable("entity.bizarre_odyssey.yoshikage_kira").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD));
                this.bossBar.setColor(BossBar.Color.PINK);
            }
            case "diavolo" -> {
                this.setCustomName(Text.translatable("entity.bizarre_odyssey.diavolo").formatted(Formatting.DARK_RED, Formatting.BOLD));
                this.bossBar.setColor(BossBar.Color.RED);
            }
            case "enrico_pucci" -> {
                this.setCustomName(Text.translatable("entity.bizarre_odyssey.enrico_pucci").formatted(Formatting.WHITE, Formatting.BOLD));
                this.bossBar.setColor(BossBar.Color.WHITE);
            }
            case "funny_valentine" -> {
                this.setCustomName(Text.translatable("entity.bizarre_odyssey.funny_valentine").formatted(Formatting.AQUA, Formatting.BOLD));
                this.bossBar.setColor(BossBar.Color.BLUE);
            }
        }
        this.bossBar.setName(this.getDisplayName());
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient) {
            this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());
            if (abilityCooldown > 0) {
                abilityCooldown--;
            } else if (this.getTarget() != null && this.getTarget().isAlive()) {
                executeBossSignatureMove(this.getTarget());
                abilityCooldown = 110;
            }
        }
    }

    private void executeBossSignatureMove(LivingEntity target) {
        if (!(this.getWorld() instanceof ServerWorld sw)) return;
        String type = getBossType();
        Vec3d dir = target.getPos().subtract(this.getPos()).normalize();

        switch (type) {
            case "dio_brando" -> {
                // Time Skip behind player + MUDA strike
                this.requestTeleport(target.getX() - dir.x * 1.5, target.getY(), target.getZ() - dir.z * 1.5);
                target.damage(sw.getDamageSources().mobAttack(this), 16.0f);
                sw.spawnParticles(ParticleTypes.SONIC_BOOM, target.getX(), target.getY() + 1.0, target.getZ(), 2, 0.2, 0.2, 0.2, 0.0);
                sw.playSound(null, this.getBlockPos(), SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.HOSTILE, 1.4f, 0.6f);
                if (target instanceof ServerPlayerEntity sp) {
                    sp.sendMessage(Text.translatable("msg.bizarre_odyssey.dio_taunt").formatted(Formatting.GOLD, Formatting.BOLD), true);
                }
            }
            case "yoshikage_kira" -> {
                // Killer Queen Coin Bomb Detonation
                sw.createExplosion(this, target.getX(), target.getY(), target.getZ(), 2.0f, World.ExplosionSourceType.NONE);
                target.damage(sw.getDamageSources().explosion(this, this), 15.0f);
                if (target instanceof ServerPlayerEntity sp) {
                    sp.sendMessage(Text.translatable("msg.bizarre_odyssey.kira_taunt").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), true);
                }
            }
            case "diavolo" -> {
                // King Crimson Epitaph Step + Impale
                this.requestTeleport(target.getX() + dir.x * 1.2, target.getY(), target.getZ() + dir.z * 1.2);
                target.damage(sw.getDamageSources().mobAttack(this), 18.0f);
                sw.spawnParticles(ParticleTypes.CRIMSON_SPORE, this.getX(), this.getY() + 1.0, this.getZ(), 50, 0.8, 0.8, 0.8, 0.1);
                if (target instanceof ServerPlayerEntity sp) {
                    sp.sendMessage(Text.translatable("msg.bizarre_odyssey.diavolo_taunt").formatted(Formatting.DARK_RED, Formatting.BOLD), true);
                }
            }
            case "enrico_pucci" -> {
                // C-Moon / Made in Heaven Gravity Launch
                target.setVelocity(dir.x * 0.8, 0.9, dir.z * 0.8);
                target.velocityModified = true;
                target.damage(sw.getDamageSources().magic(), 16.0f);
                if (target instanceof ServerPlayerEntity sp) {
                    sp.sendMessage(Text.translatable("msg.bizarre_odyssey.pucci_taunt").formatted(Formatting.AQUA, Formatting.BOLD), true);
                }
            }
            case "funny_valentine" -> {
                // D4C Dimension Hop + Love Train Reflection
                this.heal(15.0f);
                target.damage(sw.getDamageSources().magic(), 18.5f);
                sw.spawnParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 1.0, this.getZ(), 60, 1.0, 1.5, 1.0, 0.1);
                if (target instanceof ServerPlayerEntity sp) {
                    sp.sendMessage(Text.translatable("msg.bizarre_odyssey.valentine_taunt").formatted(Formatting.GOLD, Formatting.BOLD), true);
                }
            }
            default -> {
                target.damage(sw.getDamageSources().mobAttack(this), 9.0f);
            }
        }
    }

    @Override
    public void onDeath(DamageSource damageSource) {
        super.onDeath(damageSource);
        if (!this.getWorld().isClient && damageSource.getAttacker() instanceof ServerPlayerEntity player) {
            String type = getBossType();
            StoryCampaignManager.onBossOrMinionDefeated(player, type);

            switch (type) {
                case "dio_brando" -> {
                    this.dropStack(new ItemStack(ModItems.DIOS_DIARY));
                    this.dropStack(new ItemStack(ModItems.DIOS_BONE));
                    this.dropStack(new ItemStack(ModItems.DIO_HEADBAND));
                    ModAdvancementTracker.grantAdvancement(player, "story/part3_stardust_crusaders");
                }
                case "yoshikage_kira" -> {
                    this.dropStack(new ItemStack(ModItems.REQUIEM_ARROW));
                    this.dropStack(new ItemStack(ModItems.KIRA_SKULL_TIE));
                    ModAdvancementTracker.grantAdvancement(player, "story/part4_diamond_is_unbreakable");
                }
                case "diavolo" -> {
                    this.dropStack(new ItemStack(ModItems.REQUIEM_ARROW));
                    this.dropStack(new ItemStack(ModItems.GIORNO_LADYBUG_BROOCH));
                    ModAdvancementTracker.grantAdvancement(player, "story/part5_golden_wind");
                }
                case "enrico_pucci" -> {
                    this.dropStack(new ItemStack(ModItems.GREEN_BABY));
                    this.dropStack(new ItemStack(ModItems.DIOS_DIARY));
                    ModAdvancementTracker.grantAdvancement(player, "story/part6_stone_ocean");
                }
                case "funny_valentine" -> {
                    this.dropStack(new ItemStack(ModItems.SAINTS_HEART));
                    this.dropStack(new ItemStack(ModItems.SAINTS_PELVIS));
                    this.dropStack(new ItemStack(ModItems.GYRO_HAT));
                    ModAdvancementTracker.grantAdvancement(player, "story/part7_steel_ball_run");
                }
                default -> {
                    this.dropStack(new ItemStack(ModItems.STAND_ARROW));
                }
            }
        }
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        if (!"cultist_minion".equals(getBossType())) {
            this.bossBar.addPlayer(player);
        }
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString("BossType", getBossType());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("BossType")) {
            configureBossType(nbt.getString("BossType"));
        }
    }
}
