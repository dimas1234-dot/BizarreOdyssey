package com.bizarreodyssey.entity;

import com.bizarreodyssey.BizarreOdysseyMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
    public static final EntityType<StandEntity> STAND_ENTITY = Registry.register(
            Registries.ENTITY_TYPE,
            BizarreOdysseyMod.id("stand_spirit"),
            EntityType.Builder.create(StandEntity::new, SpawnGroup.MISC)
                    .dimensions(0.8f, 2.0f)
                    .maxTrackingRange(64)
                    .build()
    );

    public static final EntityType<StoryBossEntity> STORY_BOSS = Registry.register(
            Registries.ENTITY_TYPE,
            BizarreOdysseyMod.id("story_boss"),
            EntityType.Builder.create(StoryBossEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.75f, 2.05f)
                    .maxTrackingRange(80)
                    .build()
    );

    public static final EntityType<StoryMentorNpcEntity> STORY_MENTOR = Registry.register(
            Registries.ENTITY_TYPE,
            BizarreOdysseyMod.id("story_mentor"),
            EntityType.Builder.create(StoryMentorNpcEntity::new, SpawnGroup.CREATURE)
                    .dimensions(0.65f, 1.95f)
                    .maxTrackingRange(64)
                    .build()
    );

    public static void registerAll() {
        FabricDefaultAttributeRegistry.register(STAND_ENTITY, StandEntity.createStandAttributes());
        FabricDefaultAttributeRegistry.register(STORY_BOSS, StoryBossEntity.createBossAttributes());
        FabricDefaultAttributeRegistry.register(STORY_MENTOR, StoryMentorNpcEntity.createMentorAttributes());
        BizarreOdysseyMod.LOGGER.info("Registered Bizarre Odyssey Entities.");
    }
}
