package com.bizarreodyssey.util;

import com.bizarreodyssey.spec.SpecType;
import com.bizarreodyssey.stand.StandType;
import net.minecraft.nbt.NbtCompound;

public interface IJoJoPlayerData {
    StandType bizarre$getStand();
    void bizarre$setStand(StandType stand);

    SpecType bizarre$getSpec();
    void bizarre$setSpec(SpecType spec);

    boolean bizarre$isStandSummoned();
    void bizarre$setStandSummoned(boolean summoned);

    int bizarre$getWorthiness();
    void bizarre$setWorthiness(int worthiness);

    int bizarre$getStandEnergy();
    void bizarre$setStandEnergy(int energy);

    int bizarre$getStoryStage();
    void bizarre$setStoryStage(int stage);

    int bizarre$getStoryKillProgress();
    void bizarre$setStoryKillProgress(int progress);

    int bizarre$getDioBoneSteps();
    void bizarre$setDioBoneSteps(int steps);

    int bizarre$getCooldown(int slot);
    void bizarre$setCooldown(int slot, int ticks);
    void bizarre$tickCooldowns();

    NbtCompound bizarre$writeData();
    void bizarre$readData(NbtCompound nbt);
}
